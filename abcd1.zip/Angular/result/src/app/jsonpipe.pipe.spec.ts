import { JsonpipePipe } from './jsonpipe.pipe';

describe('JsonpipePipe', () => {
  it('create an instance', () => {
    const pipe = new JsonpipePipe();
    expect(pipe).toBeTruthy();
  });
});
