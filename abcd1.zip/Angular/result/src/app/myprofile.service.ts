import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Response, Headers, RequestOptionsArgs} from '@angular/http';
@Injectable()
export class MyprofileService {

  constructor(private http:Http ) { }
  getHeaders() : Headers{
    let headers:Headers = new Headers();
    headers.append('Authorization', sessionStorage.getItem('token'));
    return headers;
  }
  getProfile(username): Observable<Response> {
    return this.http.get('http://localhost:3000/users/me/'+username, {headers:this.getHeaders()})
    
  }

}
