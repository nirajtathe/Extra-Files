import { Injectable } from '@angular/core';
import { Http, Response,Headers, RequestOptionsArgs } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';

import {ScheduledExe} from './upcoming-job/scheduledExec.component'

@Injectable()
export class ScheduledExeService {

  private _scheduledUrl = 'http://PUNITP382938D:3000/schd/';
  
  constructor(private _http: Http) { }

  getSchdExeData(username:string): Observable<ScheduledExe> {
    console.log(this.getHeaders())
    return this._http.get(this._scheduledUrl+username, {headers:this.getHeaders()})
      .map((response: Response) => <ScheduledExe> response.json())
      .catch(this.handleError);
  }

  getHeaders() : Headers{
    let headers:Headers = new Headers();
    headers.append('Authorization', sessionStorage.getItem('token'));
    return headers;
  }

  private handleError(error: Response) {
    console.error(error);
    return Observable.throw(error || 'Server error');
  }

}
