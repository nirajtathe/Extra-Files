
import { LogsTemplate } from './log-entity'
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import {PrevExe} from './prevexe.component'

import { Subscription } from 'rxjs/Subscription';
import { FbdiservicesService } from '../fbdiservices.service';
import { saveAs as importedSaveAs } from "file-saver";

@Component({
    selector: 'prev-exe',
    templateUrl: './prev-exe.html'

})
export class PrevExeComponent {
    logs: LogsTemplate[];
    cloudSrch: string;
    wfSrch: string;
    dateSrch: string;
    prevExeData:PrevExe;
    

    errorMessage: string;
    private sub: Subscription;

    constructor(private _route: ActivatedRoute,
        private _router: Router,
        private _prevExeService: FbdiservicesService) {
    }

    ngOnInit(): void {
        this.getPrevExeWf();
    }

    // ngOnDestroy() {
    //     this.sub.unsubscribe();
    // }


    getPrevExeWf() {
        let username:string = sessionStorage.getItem("currentUser");
        this._prevExeService.getPrevExeData(username).subscribe(
            product => this.prevExeData = product,
            error => this.errorMessage = <any>error);

    }

    downloadFile(dfile: string){
        dfile = dfile.replace(/\\/g, "/");
        let json = JSON.parse('{ "filePth" : "'+dfile+'" }');
        console.log(json);
        this._prevExeService.downloadFile(json).subscribe(blob => {
            importedSaveAs(blob, 'hello.zip');
          });
      
    }


}
