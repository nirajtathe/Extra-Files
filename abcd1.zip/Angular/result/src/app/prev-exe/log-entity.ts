export class LogsTemplate{
    cloud:string;
    workflow:string;
    exe:Date;
    url:string;
}
