export class PrevExe{
    uname:string;
    exe_time:Date;
    wf:string;
    cloud:string;
    ucm_acc:string;
    job_name:string;
    job_package:string;
    jobid_1:number;
    jobid_2:number;
    docid:number;
    result:string;
    cloudlog_1:string;
    cloudlog_2:string;
    exe_log:string;
}
