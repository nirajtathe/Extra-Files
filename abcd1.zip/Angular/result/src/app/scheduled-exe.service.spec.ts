import { TestBed, inject } from '@angular/core/testing';

import { ScheduledExeService } from './scheduled-exe.service';

describe('ScheduledExeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ScheduledExeService]
    });
  });

  it('should be created', inject([ScheduledExeService], (service: ScheduledExeService) => {
    expect(service).toBeTruthy();
  }));
});
