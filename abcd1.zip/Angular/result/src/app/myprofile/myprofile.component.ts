import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { FormGroup } from '@angular/forms/src/model';
import { FbdiservicesService } from '../fbdiservices.service';

@Component({
  selector: 'app-myprofile',
  templateUrl: './myprofile.component.html',
  styleUrls: ['./myprofile.component.css']

})
export class MyprofileComponent {
  
  form: FormGroup;
  constructor(private fb:FormBuilder, private profileService: FbdiservicesService){
    this.form = fb.group({
      'uname':[''],
      'password':[''],
      'role':[''],
      'account':[''],
      'manager':[''],
      'name':['']
    })
  }

  user = {
    name:String,
    username:String,
    password:String,
    role:String,
    manager:String,
    account:String
  }

  ngOnInit(){
    var username = sessionStorage.getItem('currentUser');
    this.profileService.getProfile(username).subscribe(
      res => {
        
        this.user = res.json()[0];
        console.log(this.user);
        this.form.setValue(this.user);
      }, 
      err => {
        this.user = null;
      }
    );
  }

}
