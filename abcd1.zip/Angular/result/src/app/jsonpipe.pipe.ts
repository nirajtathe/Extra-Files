import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'jsonpipe'
})
export class JsonpipePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    let json = JSON.stringify(value);
    json = json.replace('{', '');
    json = json.replace('}', '');
    json = json.replace(/"/g,"");
    json = json.replace(/:/g," : ")
              .replace(/,/g, ' , \r\n   ')
    return json;
  }

}
