// imports
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule, JsonpModule } from '@angular/http';
import { FileSelectDirective, FileDropDirective } from 'ng2-file-upload';

import { ReactiveFormsModule } from '@angular/forms';

//components
import { MainPageComponent } from './main-page/main-page.component';
import { LoginComponent } from './login/login.component';
import { MyprofileComponent } from './myprofile/myprofile.component';
import { AdminComponent } from './admin/admin.component';
import { AddUserComponent } from './admin/adduser/add-user.component';
import { EditUserComponent } from './admin/edituser/edit-user.component';
import { RemoveUserComponent } from './admin/removeuser/remove-user.component';
import { RemovePassComponent } from './admin/resetpass/reset-pass.component';
import { PrevExeComponent } from './prev-exe/prev-exe.component';
import { CurrentJobComponent } from './current-job/current-job.component';
import { UpcomingJobComponent } from './upcoming-job/upcoming-job.component';
import { ExecuteWfComponent } from './execute-wf/execute-wf.component';
import { FooterComponent } from './footer/footer.component'
//pipes
import { TemplateFilterByCloudPipe } from './main-page/main-page-cloud.pipe';
import { TemplateFilterByWfPipe } from './main-page/main-page-wf.pipe';
import { LogFilterByCloudPipe } from './prev-exe/cloud.pipe';
import { LogFilterByWfPipe } from './prev-exe/workflow.pipe';
import { LogFilterByDatePipe } from './prev-exe/exe-date.pipe';


// app Compo
import { AppComponent } from './app.component';

//service
import { SharedService } from './services/shared-services';

//guard
import { AuthGuard } from './login/auth.guard';
import { AdminAuthGuard } from './admin/admin-auth.guard';
import { TemplateComponentComponent } from './template-component/template-component.component';
import { HelpComponent } from './help/help.component';
import { AllDbComponent } from './admin/all-db/all-db.component';
import { AllWfDataComponent } from './admin/all-wf-data/all-wf-data.component';
import { WfPipePipe } from './admin/all-wf-data/wf-pipe.pipe';
import { JbPipePipe } from './admin/all-wf-data/jb-pipe.pipe';
import { NamePipePipe } from './admin/all-db/name-pipe.pipe';
import { AcctPipePipe } from './admin/all-db/acct-pipe.pipe';
import { WindowRefService } from './window-ref.service';
import { FbdiservicesService } from './fbdiservices.service';
import { JsonpipePipe } from './jsonpipe.pipe';


@NgModule({

  imports: [BrowserModule,ReactiveFormsModule,
    FormsModule, HttpModule, ReactiveFormsModule,
    RouterModule.forRoot([
      { path: '', component: LoginComponent },
      { path: 'temp', component: TemplateComponentComponent },
      { path: 'main-page', component: MainPageComponent, canActivate: [AuthGuard] },
      { path: 'exe', component: ExecuteWfComponent, canActivate: [AuthGuard] },
      { path: 'login', component: LoginComponent },
      { path: 'my-app', component: AppComponent },
      { path: 'my-acc', component: MyprofileComponent },
      { path: 'help', component: HelpComponent, canActivate: [AuthGuard] },
      {
        path: 'admin', component: AdminComponent, canActivate: [AdminAuthGuard], children: [
          { path: 'adduser', component: AddUserComponent },
          { path: 'edituser', component: EditUserComponent },
          { path: 'removeuser', component: RemoveUserComponent },
          { path: 'resetpass', component: RemovePassComponent },
          { path: 'allUser', component: AllDbComponent },
          { path: 'wfdetails', component: AllWfDataComponent}
        ]
      },
      {
        path: 'prev', component: PrevExeComponent, canActivate: [AuthGuard],
      },
      { path: 'current', component: CurrentJobComponent, canActivate: [AuthGuard] },
      { path: 'upcoming', component: UpcomingJobComponent, canActivate: [AuthGuard] },

    ])
  ],
  declarations: [AppComponent,
    TemplateFilterByWfPipe,
    FooterComponent,
    AppComponent, MyprofileComponent,
    CurrentJobComponent,
    UpcomingJobComponent,
    LoginComponent,
    ExecuteWfComponent,
    MainPageComponent,
    FileSelectDirective,
    LoginComponent,
    AddUserComponent,
    AdminComponent,
    LogFilterByCloudPipe,
    LogFilterByWfPipe,
    LogFilterByDatePipe,
    PrevExeComponent,
    EditUserComponent,
    RemoveUserComponent,
    RemovePassComponent,
    TemplateFilterByCloudPipe,
    TemplateComponentComponent,
    HelpComponent,
    AllDbComponent,
    AllWfDataComponent,
    WfPipePipe,
    JbPipePipe,
    NamePipePipe,
    AcctPipePipe,
    JsonpipePipe],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent],
  providers: [SharedService, AuthGuard, AdminAuthGuard, WindowRefService, FbdiservicesService],
})
export class AppModule { }
