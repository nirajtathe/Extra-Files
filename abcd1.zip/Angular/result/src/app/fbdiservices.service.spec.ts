import { TestBed, inject } from '@angular/core/testing';

import { FbdiservicesService } from './fbdiservices.service';

describe('FbdiservicesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FbdiservicesService]
    });
  });

  it('should be created', inject([FbdiservicesService], (service: FbdiservicesService) => {
    expect(service).toBeTruthy();
  }));
});
