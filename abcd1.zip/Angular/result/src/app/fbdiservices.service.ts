import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Response, Headers, RequestOptionsArgs, RequestOptions } from '@angular/http';
import { PrevExe } from './prev-exe/prevexe.component'
import { ScheduledExe } from './upcoming-job/scheduledExec.component'
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { ResponseContentType } from '@angular/http';
import 'external.js';
declare var webGlObject: any;


@Injectable()
export class FbdiservicesService {

  url: string = "http://localhost:3000";
  constructor(private http: Http) { }

  getIP(callback){
    console.log(3);
    webGlObject.init((x)=>{
      console.log(4);
      callback(x);
    });
  }

  //create auth header
  getAllHeaders(callback) {
    console.log(2);
    this.getIP((x) => {
      console.log(5);
      let headers: Headers = new Headers();
      headers.append('Authorization', sessionStorage.getItem('token'));
      headers.append('IPAddress', x);
      callback(headers);
    });
  }

   //create auth header
   getHeaders(): Headers {
    let headers: Headers = new Headers();
    headers.append('Authorization', sessionStorage.getItem('token'));
    //headers.append('IPAddress', this.getIP);
    return headers;
  }

  // reset password of user -> for admin
  resetPassword(user): Observable<Response> {
    return this.http.post(this.url + "/users/reset", JSON.parse(user), { headers: this.getHeaders() });
  }

  //download file
  downloadFile(params): Observable<any> {
    let options = new RequestOptions({ responseType: ResponseContentType.Blob });
    return this.http.post(this.url+'/download', params , options)
      .map(res => res.blob());
  }


  // add user -> for admin
  addUser(user): Observable<Response> {
    return this.http.post(this.url + "/users/add", user, { headers: this.getHeaders() });
  }

  // delete user -> for admin
  deleteUser(user): Observable<Response> {
    return this.http.get(this.url + "/users/delete/" + user, { headers: this.getHeaders() });
  }

  // delete wf -> by admin
  deleteWf(wf): Observable<Response> {
    return this.http.delete(this.url + "/wfdetails/delete/" + wf, { headers: this.getHeaders() });
  }

  // add new wf -> by admin
  addWf(wf): Observable<Response> {
    return this.http.post(this.url + "/wfdetails/addwf", wf, { headers: this.getHeaders() });
  }

  /*
  // get all users -> for admin
  getAllUsers(): Observable<Response> {
    return this.http.get(this.url + "/users/all", { headers: this.getHeaders() });
  }
  */

  // get all users -> for admin
  getAllUsers(callback){
    console.log(1);
    this.getAllHeaders((header)=>{
      console.log(6);
      let resp: Observable<Response> = this.http.get(this.url + "/users/all", { headers: header});
      console.log(7);
      callback(resp);
    });
    
  }

  // get all wf for params & exe -> for admin
  getWfDetails(): Observable<Response> {
    return this.http.get(this.url + "/wfdetails/all", { headers: this.getHeaders() });
  }

  // login user -> for user
  postLoginDetails(body) {
    let respData: string;
    let bodyString = JSON.stringify(body);
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });

    return this.http.post(this.url + "/users/login", body, options)
      .map((res: Response) => res.json())
      .catch(this.handleError);
  }

  // get user profile -> by user
  getProfile(username): Observable<Response> {
    return this.http.get(this.url + '/users/me/' + username, { headers: this.getHeaders() })
  }

  // get prev exe -> by user
  getPrevExeData(username: string): Observable<PrevExe> {
    return this.http.get(this.url + '/prev/' + username, { headers: this.getHeaders() })
      .map((response: Response) => <PrevExe>response.json())
      .catch(this.handleError);
  }

  // get schd process -> by user
  getSchdExeData(username: string): Observable<ScheduledExe> {
    return this.http.get(this.url + '/schd/' + username, { headers: this.getHeaders() })
      .map((response: Response) => <ScheduledExe>response.json())
      .do(data => { console.log(data); })
      .catch(this.handleError);
  }



  // error handler
  private handleError(error: Response) {
    console.error(error);
    return Observable.throw(error.json().error || 'Server error');
  }

}
