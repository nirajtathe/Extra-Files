import { Component, OnInit } from '@angular/core';
import { MainPageComponent }  from './main-page/main-page.component';
import { PlatformLocation } from '@angular/common';
import { Router, ActivatedRoute, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router'

@Component({
  selector: 'my-app',
  templateUrl: './app-component.html',
  styleUrls: ['./app-component.css']
})
export class AppComponent implements OnInit  { 
  user:string;

  constructor(private location: PlatformLocation, private router: Router, private route: ActivatedRoute){
    
  }
  
  ngOnInit(){
    
    this.user = sessionStorage.getItem('currentUser');
    this.location.onPopState(() => {
        sessionStorage.removeItem('currentUser');
    });
    setTimeout(()=>{    //<<<---    using ()=> syntax
      this.router.navigate(['/login']);
    },1500);
  }
  name = 'Angular'; 
  logout() {
        sessionStorage.removeItem('currentUser');
    }
}
