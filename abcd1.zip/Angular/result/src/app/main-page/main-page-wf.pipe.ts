import {  PipeTransform, Pipe } from '@angular/core';
import { Templates } from './template-entity'

@Pipe({
    name: 'wfFilter'
})
export class TemplateFilterByWfPipe implements PipeTransform {

    transform(value: Templates[], filterBy: string): Templates[] {
        filterBy = filterBy ? filterBy.toLocaleLowerCase() : null;
        var item = filterBy ? value.filter((product: Templates) =>
            product.wf.toLocaleLowerCase().indexOf(filterBy) !== -1) : value;
        return item;
    }
}
