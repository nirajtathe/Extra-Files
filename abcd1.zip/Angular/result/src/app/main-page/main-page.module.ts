import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

//components
import { MainPageComponent } from './main-page.component';
import { TemplateFilterByCloudPipe } from './main-page-cloud.pipe';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [
    MainPageComponent,
    TemplateFilterByCloudPipe,
  ],
})
export class MainPageRouting { }
