export class Templates {
    select: boolean;
    cloud:string;
    wf:string;
    desc:string;
    excel:string;
    ucm:string;
    job:string;
    paramkey:string[];
    paramvalue:string;
}
