import { TestBed, inject } from '@angular/core/testing';

import { PrevExeService } from './prev-exe.service';

describe('PrevExeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PrevExeService]
    });
  });

  it('should be created', inject([PrevExeService], (service: PrevExeService) => {
    expect(service).toBeTruthy();
  }));
});
