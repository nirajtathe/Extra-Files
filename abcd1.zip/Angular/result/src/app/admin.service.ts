import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Response, Headers, RequestOptionsArgs} from '@angular/http';
@Injectable()
export class AdminService {

  constructor(private http:Http) { }

  url:string = "http://localhost:3000";

  getHeaders() : Headers{
    let headers:Headers = new Headers();
    headers.append('Authorization', sessionStorage.getItem('token'));
    return headers;
  }

  resetPassword(user):Observable<Response>{
    return this.http.post(this.url+"/users/reset", JSON.parse(user), {headers:this.getHeaders()});
  }

  addUser(user):Observable<Response>{
    return this.http.post(this.url+"/users/add", user, {headers:this.getHeaders()});
  }

  deleteUser(user):Observable<Response>{
    return this.http.get(this.url+"/users/delete/"+user, {headers:this.getHeaders()});
  }

}
