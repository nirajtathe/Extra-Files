import { Component, OnInit, Input, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router'

import { Subscription } from 'rxjs/Subscription';
import { FbdiservicesService } from '../fbdiservices.service';

@Component({
    moduleId: module.id,
    selector: 'login',
    templateUrl: 'login.html',
    styleUrls: ['login.css']
})

export class LoginComponent implements OnInit {
    username: string;
    password: string;
    message: string;
    returnUrl: string;
    @ViewChild('panel', { read: ElementRef }) public panel: ElementRef;

    constructor(private router: Router, private route: ActivatedRoute, private _loginservice: FbdiservicesService) { }

    ngOnInit() {

        this.returnUrl = this.route.snapshot.queryParams['returnUrl'];
        if (sessionStorage.getItem('currentUser') && this.returnUrl != '/admin') {
            console.log('user already logged in!!')
            this.returnUrl = 'current';
            this.router.navigate([this.returnUrl]);
        }
    }
    role: String;
    errorMessage: String;
    onLoginClick() {
        let input = '{"username":"' + this.username + '", "password":"' + this.password + '"}';

        console.log(input);
        this._loginservice.postLoginDetails(input).subscribe(
            (res) => {     
                console.log(res);   
                let token = res['token'];
                this.role = res['role'];
                if (this.role == 'Admin' && (this.returnUrl == '/admin' || this.returnUrl == undefined)) {
                    sessionStorage.setItem('admin', this.username);
                    sessionStorage.setItem('token', token);
                    this.router.navigate(['admin']);
                } else if (this.role == 'Invalid User!') {
                    this.message = "Invalid Username or Password";
                } else if ((this.role != 'Invalid User!' && this.role!='Admin') && this.returnUrl != '/admin'){
                    sessionStorage.setItem('currentUser', this.username);
                    this.router.navigate([this.returnUrl || 'current']);
                    sessionStorage.setItem('token', token);
                }else{
                    this.message = "Incorrect Username or Password";
                }
                
            },
            error => {this.message =  <any>error;});

        console.log(this.username + " " + this.password + " " + this.returnUrl + " " + this.role + " " + this.errorMessage);
        /*
        if (this.username == 'a' && this.password == 'b' && this.returnUrl!='/admin') {
            sessionStorage.setItem('currentUser', this.username);
            this.router.navigate([this.returnUrl || 'current']);
        } else if(this.username == 'b' && this.password == 'b'){
            sessionStorage.setItem('admin', this.username);
            this.router.navigate(['admin']);
        }else{
            this.message = "Invalid Username or Password";
        }
        */
    }
    flag: boolean = false;
    toLogin(el) {
        this.flag = !this.flag;
        setTimeout(function () {
            window.scrollTo(0, document.body.scrollHeight);
        }, 150);


    }

}
