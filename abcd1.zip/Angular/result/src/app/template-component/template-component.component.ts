import { Component, OnInit } from '@angular/core';
import { PlatformLocation } from '@angular/common';

import { Router, ActivatedRoute, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router'


@Component({
  selector: 'app-template-component',
  templateUrl: './template-component.component.html',
  styleUrls: ['./template-component.component.css']
})
export class TemplateComponentComponent implements OnInit {

user:string;
show:boolean;

  constructor(private location: PlatformLocation, private router: Router, private route: ActivatedRoute){
    this.user = sessionStorage.getItem('currentUser');
  }


  
  ngOnInit(){
    
    this.location.onPopState(() => {
        sessionStorage.removeItem('currentUser');
    });
   
    if(this.router.url=='/login' || this.router.url.startsWith("/login")){
      this.show = false;
    }else{
      this.show = true;
    }
  }
  name = 'Angular'; 
  logout() {
        sessionStorage.removeItem('currentUser');
        sessionStorage.removeItem('admin');
        sessionStorage.removeItem('token');
    }
}
