import { Component } from '@angular/core';
import { FbdiservicesService } from '../../fbdiservices.service';


@Component({
    selector: 'removeuser',
    templateUrl: './remove-user.html',
})

export class RemoveUserComponent {
    
    username:string;
    message:string;
    constructor(private adminService:FbdiservicesService ){}

    onRemoveClick(){
        if (this.username == undefined || this.username.length == 0) {
            this.message = "Enter Email ID";
            return;
        }

        this.adminService.deleteUser(this.username).subscribe(
            res => alert("Deleted!"),
            error=> alert('error!')
        );


    }
}
