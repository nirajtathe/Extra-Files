import { WfPipePipe } from './wf-pipe.pipe';

describe('WfPipePipe', () => {
  it('create an instance', () => {
    const pipe = new WfPipePipe();
    expect(pipe).toBeTruthy();
  });
});
