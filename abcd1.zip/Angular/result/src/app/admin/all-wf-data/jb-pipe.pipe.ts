import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'jbPipe'
})
export class JbPipePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    console.log(args);
    args = args ? args.toLocaleLowerCase() : null;
    var item = args ? value.filter((product) =>
        product.JobName.toLocaleLowerCase().indexOf(args) !== -1) : value;
    return item;
  }

}
