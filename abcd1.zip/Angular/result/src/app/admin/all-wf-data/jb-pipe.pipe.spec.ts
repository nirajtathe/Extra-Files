import { JbPipePipe } from './jb-pipe.pipe';

describe('JbPipePipe', () => {
  it('create an instance', () => {
    const pipe = new JbPipePipe();
    expect(pipe).toBeTruthy();
  });
});
