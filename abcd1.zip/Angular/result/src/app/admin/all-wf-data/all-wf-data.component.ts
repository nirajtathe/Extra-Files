import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FbdiservicesService } from '../../fbdiservices.service';
import { Router, Route } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-all-wf-data',
  templateUrl: './all-wf-data.component.html',
  styleUrls: ['./all-wf-data.component.css']
})
export class AllWfDataComponent implements OnInit {
  wfname: string;
  jobname:string;
  elements;

  ngOnInit(){
    this.getData();
  }


  getData(){
    this.wfdetails.getWfDetails().subscribe(
        res => {this.elements = res.json()},
        err => {console.log(err)}
      )
  }
  form: FormGroup;
    constructor(
        private wfdetails:FbdiservicesService, 
        private fb: FormBuilder,
        private router:Router) {
        this.form = fb.group({
            'Workflow': ['', Validators.required],
            'JobName': ['', Validators.required],
            'package': ['', Validators.required],
            'num': ['', Validators.required]
        });
    }

    isValid(control) {
        return this.form.controls[control].invalid && this.form.controls[control].touched;
    }

    onRegisterClick(){
        console.log(this.form.value);
        this.wfdetails.addWf(this.form.value).subscribe(
            res => {alert('Wf created');this.form.reset();this.getData();},
            err=> {alert('Error!')}
        );
    }


    onRemoveClick(wfname){
        // if (this.uname == undefined || this.uname.length == 0) {
        //     //this.message = "Enter Email ID";
    
        //     return;
        // }
        
        
        this.wfdetails.deleteWf(wfname).subscribe(
            res => {alert("Deleted!");this.getData();},
            error=> alert('error!')
        );

        
    
    
    }
}
