import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'wfPipe'
})
export class WfPipePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    args = args ? args.toLocaleLowerCase() : null;
    var item = args ? value.filter((product) =>
        product.Workflow.toLocaleLowerCase().indexOf(args) !== -1) : value;
    return item;
  }

}
