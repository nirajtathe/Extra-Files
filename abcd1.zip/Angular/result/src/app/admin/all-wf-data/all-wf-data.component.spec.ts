import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllWfDataComponent } from './all-wf-data.component';

describe('AllWfDataComponent', () => {
  let component: AllWfDataComponent;
  let fixture: ComponentFixture<AllWfDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllWfDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllWfDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
