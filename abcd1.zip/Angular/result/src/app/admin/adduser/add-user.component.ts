import { Component } from '@angular/core';
import { AdminService } from '../../admin.service';
import { FormBuilder } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FbdiservicesService } from '../../fbdiservices.service';

@Component({
    selector: 'adduser',
    templateUrl: './add-user.html',
    styleUrls: ['./add-user.css']
})
export class AddUserComponent {
    
    form: FormGroup;
    constructor(private admin: FbdiservicesService, private fb: FormBuilder) {
        this.form = fb.group({
            'username': ['', Validators.required],
            'name': ['', Validators.required],
            'password': ['', Validators.required],
            'account': ['', Validators.required],
            'role': ['', Validators.required],
            'manager': ['', Validators.required],
        });
    }

    isValid(control) {
        return this.form.controls[control].invalid && this.form.controls[control].touched;
    }

    onRegisterClick(){
        console.log(this.form.value);
        this.admin.addUser(this.form.value).subscribe(
            res => {alert('user created');this.form.reset()},
            err=> {alert('Error!')}
        );
    }
}
