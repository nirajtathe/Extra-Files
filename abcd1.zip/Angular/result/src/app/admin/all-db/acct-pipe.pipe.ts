import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'acctPipe'
})
export class AcctPipePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    console.log(args);
    args = args ? args.toLocaleLowerCase() : null;
    var item = args ? value.filter((product) =>
        product.account.toLocaleLowerCase().indexOf(args) !== -1) : value;
    return item;
  }

}
