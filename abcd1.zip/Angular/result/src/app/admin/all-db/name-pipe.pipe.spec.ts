import { NamePipePipe } from './name-pipe.pipe';

describe('NamePipePipe', () => {
  it('create an instance', () => {
    const pipe = new NamePipePipe();
    expect(pipe).toBeTruthy();
  });
});
