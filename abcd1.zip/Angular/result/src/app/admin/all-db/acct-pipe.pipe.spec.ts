import { AcctPipePipe } from './acct-pipe.pipe';

describe('AcctPipePipe', () => {
  it('create an instance', () => {
    const pipe = new AcctPipePipe();
    expect(pipe).toBeTruthy();
  });
});
