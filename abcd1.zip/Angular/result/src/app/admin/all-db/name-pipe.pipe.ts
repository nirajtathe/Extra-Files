import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'namePipe'
})
export class NamePipePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    console.log(args);
    args = args ? args.toLocaleLowerCase() : null;
    var item = args ? value.filter((product) =>
        product.uname.toLocaleLowerCase().indexOf(args) !== -1) : value;
    return item;
  }

}
