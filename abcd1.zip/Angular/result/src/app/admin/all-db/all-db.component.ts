import { Component, OnInit } from '@angular/core';
import { FbdiservicesService } from '../../fbdiservices.service';
import { Router, Route } from '@angular/router';

@Component({
  selector: 'app-all-db',
  templateUrl: './all-db.component.html',
  styleUrls: ['./all-db.component.css']
})
export class AllDbComponent implements OnInit {
  name: string;
  acct: string;
  elements;
  constructor(private allDcomp:FbdiservicesService, private router:Router) { }
  
  ngOnInit(){
    this.getData();
    
  }

  getData(){
    this.allDcomp.getAllUsers((x)=>{
      x.subscribe(
        res => {this.elements = res.json()},
        err => {console.log(err)}
      );
    });
  }

  onRemoveClick(uname){
    // if (this.uname == undefined || this.uname.length == 0) {
    //     //this.message = "Enter Email ID";

    //     return;
    // }
    

    this.allDcomp.deleteUser(uname).subscribe(
        res => {alert("Deleted!");this.getData();
        
      },
        error=> alert('error!')
    );


}

}
