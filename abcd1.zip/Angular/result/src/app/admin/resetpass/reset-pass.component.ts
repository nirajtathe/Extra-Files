import { Component } from '@angular/core';
import { FbdiservicesService } from '../../fbdiservices.service';


@Component({
    selector: 'resetpass',
    templateUrl: './reset-pass.html',

})

export class RemovePassComponent {
    
    username:string;
    password:string;
    message:string;

    constructor(private adminService:FbdiservicesService ){}
    
    onResetClick(){
        if (this.username == undefined || this.username.length == 0) {
            this.message="Enter email";
            return;
        } else if (this.password == undefined || this.password.length == 0) {
            this.message="Enter password";
            return;
        }

        let json = '{"username":"'+this.username+'","password":"'+this.password+'"}';
        this.adminService.resetPassword(json).subscribe(
            res=>alert("updated!"),
            error=>alert("error!")
        );
    }
}
