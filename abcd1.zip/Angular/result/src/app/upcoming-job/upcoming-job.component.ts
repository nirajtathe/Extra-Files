import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { ScheduledExe } from './scheduledExec.component';

import { Subscription } from 'rxjs/Subscription';
import { FbdiservicesService } from '../fbdiservices.service';

@Component({
  selector: 'app-upcoming-job',
  templateUrl: './upcoming-job.component.html',
  styleUrls: ['./upcoming-job.component.css']
})
export class UpcomingJobComponent implements OnInit {


  schdData:ScheduledExe;
    

    errorMessage: string;
    private sub: Subscription;

    constructor(private _route: ActivatedRoute,
        private _router: Router,
        private _schdService: FbdiservicesService) {
    }
 
ngOnInit(): void {
        this.getSchdWfData();
    }


    getSchdWfData() {
        let username:string = sessionStorage.getItem("currentUser");
        this._schdService.getSchdExeData(username).subscribe(
            product => {
              this.schdData = product
            },
            error => this.errorMessage = error);

    }

    
    onBack(): void {
        this._router.navigate(['/products']);
    }

    

}
