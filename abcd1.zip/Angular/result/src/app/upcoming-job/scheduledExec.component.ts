export class ScheduledExe{
    uname:string;
    sch_at:Date;
    exe_at:Date;
    wf:string;
    cloud:string;
    param:string;
}
