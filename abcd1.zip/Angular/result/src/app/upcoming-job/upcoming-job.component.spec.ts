import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpcomingJobComponent } from './upcoming-job.component';

describe('UpcomingJobComponent', () => {
  let component: UpcomingJobComponent;
  let fixture: ComponentFixture<UpcomingJobComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpcomingJobComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpcomingJobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
