import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http/src/static_response';
import { Headers, RequestOptionsArgs} from '@angular/http';

@Injectable()
export class AllService {

  constructor(private http:Http) { }

  url:string = "http://localhost:3000";
  getHeaders() : Headers{
    let headers:Headers = new Headers();
    headers.append('Authorization', sessionStorage.getItem('token'));
    return headers;
  }


  getAllUsers():Observable<Response>{
    return this.http.get(this.url+"/users/all", {headers:this.getHeaders()});
  }

  getWfDetails():Observable<Response>{
    return this.http.get(this.url+"/wfdetails/all", {headers:this.getHeaders()});
  }
}
