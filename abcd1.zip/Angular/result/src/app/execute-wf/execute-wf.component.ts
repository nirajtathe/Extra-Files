import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-execute-wf',
  templateUrl: './execute-wf.component.html',
  styleUrls: ['./execute-wf.component.css']
})
export class ExecuteWfComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
