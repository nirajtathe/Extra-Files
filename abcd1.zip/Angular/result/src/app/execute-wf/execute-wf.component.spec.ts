import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExecuteWfComponent } from './execute-wf.component';

describe('ExecuteWfComponent', () => {
  let component: ExecuteWfComponent;
  let fixture: ComponentFixture<ExecuteWfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExecuteWfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExecuteWfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
