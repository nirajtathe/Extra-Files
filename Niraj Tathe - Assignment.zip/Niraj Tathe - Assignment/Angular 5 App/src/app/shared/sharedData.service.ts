import { Injectable, OnInit } from '@angular/core';

@Injectable()
export class SharedDataService implements OnInit{

  private device:{devicename: string, loopback:string,
                  interfaces: { name:string, ipadd: string}[]}[]=[];
 
  constructor() { }
  
  ngOnInit(){
  }

  getData(){
    return this.device;
  }

  addData(device){
    this.device.push(device);
    console.log(this.device);
  }
  
}
