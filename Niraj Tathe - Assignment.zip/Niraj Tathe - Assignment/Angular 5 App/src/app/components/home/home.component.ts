import { Component, OnInit, Input, Inject } from '@angular/core';
import { SharedDataService } from '../../shared/sharedData.service';

import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

@Component({
  selector: 'app-popup',
  templateUrl: './popup.component.html'
})
export class PopupComponent implements OnInit{
  interfaces: { name:string, ipadd: string}[]=[];
  interfaceName1: string;
   interfaceIpadd1: string;
  devices=[];
  constructor(
    public dialogRef: MatDialogRef<PopupComponent>,
    private sharedData:SharedDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  editData(i){
    this.interfaceName1=this.interfaces[i].name;
    this.interfaceIpadd1=this.interfaces[i].ipadd;
    this.onDeleteInterface(i);
  }


  onAdd(formData){
    this.devices[this.data.index].interfaces.push({name:formData.form.value.interfacename ,
          ipadd: formData.form.value.interfaceipadd});
    this.interfaces = this.devices[this.data.index].interfaces;
    formData.reset();
    //console.log(formData);
  }

  onDeleteInterface(ind){
    this.devices[this.data.index].interfaces.splice(ind,1);
    this.interfaces = this.devices[this.data.index].interfaces;
  }

  checkUniqueInterfaceName(interfaceName: string){
    
    let result =false;
    if(interfaceName === null || interfaceName ===undefined ||  this.interfaces=== undefined)
      return result;
   
    for(let dinterface of this.interfaces){
      
        if(dinterface.name === interfaceName){
          result=true;
          break;
        }
      
    }
    return result;
  }

  checkUniqueInterfaceLoopback(interfaceIpadd: string){
    let result =false;

    if( this.interfaces=== undefined ||  this.interfaces.length == 0 || interfaceIpadd== null || interfaceIpadd.length == 0)
      return result;

    //inner interfac check
    
    for(let dinterface of this.interfaces){
     
        if(dinterface.ipadd === interfaceIpadd){
          result=true;
          break;
        }


    }
  
    if(this.devices.length == 0)
      return result;
    
    for(let device of this.devices){
      if(device.loopback === interfaceIpadd)
      {
        result=true;
        break;
      }
      for(let dinterface of device.interfaces){
        if(dinterface.ipadd === interfaceIpadd){
          result=true;
          break;
        }
      }
      if(result=== true){
        break;
      }
    }
    
    return result;
  }

  checkInterfaceName(data:string){
    let result=false;
    if(data== null)
      return false;
    if(data.startsWith('Loopback'))
      result= true;
    
    return result;
  }
  
  ipValidator(loopback){
    if(loopback==null)
      return false;
    var blocks = loopback.split(".");
    if(blocks.length === 4) {
      return blocks.every(function(block) {
        return !isNaN(block) && parseInt(block,10) >=0 && parseInt(block,10) <= 255;
      });
    }
    return false;
  }

  ngOnInit(){
    this.devices=this.sharedData.getData();
    this.interfaces = this.devices[this.data.index].interfaces;
  }

}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  @Input('matTooltip')message: string="No Interface Data Available";
  interfaces: { name:string, ipadd: string}[]=[];
  devices=[];

  animal: string;
  name: string;

  constructor(private sharedData:SharedDataService, public dialog: MatDialog){}
  
  openDialog(i): void {
    let dialogRef = this.dialog.open(PopupComponent, {
      width: '600px',
      data: { index: i }
    });

    dialogRef.afterClosed().subscribe(result => {
      //console.log('The dialog was closed');
      //this.animal = result;
    });
  }

    ngOnInit() {
    this.devices=this.sharedData.getData();
  }
  resetMsg(){
    this.message="No Interface Data Available";
  }

  updateMsg(i){
    var interfaces=this.devices[i].interfaces;
    if( interfaces!==undefined && interfaces.length !== 0){
      this.message="Interface Data:";//\nSR No\tInterface Name\tIP";
      var count= interfaces.length;
      for(var j=0;j<count;j++){
        this.message+=" [ "+(j+1)+" , "+interfaces[j].name+" ,"+interfaces[j].ipadd+" ] ,";//'\n<br/>'; 
      }
    }
  }

  onAdd(formData){
    this.devices.push({devicename:formData.form.value.hostname ,
          loopback: formData.form.value.loopback, interfaces:[]});
    formData.reset();
    //console.log(formData);
  }
  
  onDelete(index: number){
    this.devices.splice(index,1);
  }

  checkUniqueHost(hostname: string){
    let result =false;
    if(this.devices.length == 0 || hostname== null || hostname.length == 0)
      return result;
    for(let device of this.devices){
      if(device.devicename === hostname){
        result=true;
        break;
      }
    }
    return result;
  }

  checkUniqueDeviceLoopback(loopback:string){
    let result =false;
    if(this.devices.length == 0 || loopback== null || loopback.length == 0)
      return result;
    for(let device of this.devices){
      if(device.loopback === loopback){
        result=true;
        break;
      }
      
      for(let dinterface of device.interfaces){
          if(dinterface.ipadd === loopback){
            result=true;
            break;
          }
        }
      
      if(result=== true){
        break;
      }
    }

    if(this.interfaces.length == 0)
      return result;

    for(let dinterface of this.interfaces){
        if(dinterface.ipadd === loopback){
          result=true;
          break;
        }
    }
    return result;
  }

  ipValidator(loopback){
    if(loopback==null)
      return false;
    var blocks = loopback.split(".");
    if(blocks.length === 4) {
      return blocks.every(function(block) {
        return !isNaN(block) && parseInt(block,10) >=0 && parseInt(block,10) <= 255;
      });
    }
    return false;
  }

}
