import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { DirectExeComponent } from './components/direct-exe/direct-exe.component';
import { ScheduleExeComponent } from './components/schedule-exe/schedule-exe.component';
import { HomeComponent } from './components/home/home.component';
import { CurrentExeComponent } from './components/current-exe/current-exe.component';
import { HistoryComponent } from './components/history/history.component';

const appRoutes: Routes= [
    { path : '', redirectTo: '/home', pathMatch: 'full' },
    { path : 'home', component: HomeComponent},
    { path : 'currentexe', component: CurrentExeComponent},
    { path : 'exenow', component: DirectExeComponent},
    { path : 'history', component: HistoryComponent},
    { path : 'scheduleexe', component: ScheduleExeComponent}
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }