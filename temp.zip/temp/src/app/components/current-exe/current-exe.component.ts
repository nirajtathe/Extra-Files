import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-current-exe',
  templateUrl: './current-exe.component.html',
  styleUrls: ['./current-exe.component.css']
})
export class CurrentExeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
