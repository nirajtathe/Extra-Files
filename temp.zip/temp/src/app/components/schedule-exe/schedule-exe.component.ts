import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-schedule-exe',
  templateUrl: './schedule-exe.component.html',
  styleUrls: ['./schedule-exe.component.css']
})
export class ScheduleExeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
