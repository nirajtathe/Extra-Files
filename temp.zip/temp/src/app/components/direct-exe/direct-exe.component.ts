import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-direct-exe',
  templateUrl: './direct-exe.component.html',
  styleUrls: ['./direct-exe.component.css']
})
export class DirectExeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
