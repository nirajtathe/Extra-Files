import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { DirectExeComponent } from './components/direct-exe/direct-exe.component';
import { ScheduleExeComponent } from './components/schedule-exe/schedule-exe.component';
import { HomeComponent } from './components/home/home.component';
import { CurrentExeComponent } from './components/current-exe/current-exe.component';
import { HistoryComponent } from './components/history/history.component';

import { WsCallService } from './shared/ws-call.service';

@NgModule({
  declarations: [
    AppComponent,
    DirectExeComponent,
    ScheduleExeComponent,
    HomeComponent,
    CurrentExeComponent,
    HistoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
