//Assignment 1
var Client = require('node-rest-client').Client;
var client = new Client();

var getUrl= "http://tw-http-hunt-api-1062625224.us-east-2.elb.amazonaws.com/challenge/input";
var postUrl= "http://tw-http-hunt-api-1062625224.us-east-2.elb.amazonaws.com/challenge/output";

var userID= "HyQ4w72Jz";
var Headers = { "Content-Type": "application/json",
	    			"userId" : userID };

var argsGet = {
	headers: Headers
};

client.get(getUrl, argsGet, function (data, response) {
    var argsPost = {
	    data: { "count": data.length },
	    headers: Headers
	};

	client.post(postUrl, argsPost, function (data, response) {
	    console.log(data);    
	});
});
