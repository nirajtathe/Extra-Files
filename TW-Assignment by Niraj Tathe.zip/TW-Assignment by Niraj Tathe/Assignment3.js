//Assignment3
var Client = require('node-rest-client').Client;
var client = new Client();

var getUrl= "http://tw-http-hunt-api-1062625224.us-east-2.elb.amazonaws.com/challenge/input";
var postUrl= "http://tw-http-hunt-api-1062625224.us-east-2.elb.amazonaws.com/challenge/output";

var userID= "HyQ4w72Jz";
var Headers = { "Content-Type": "application/json",
	    			"userId" : userID };

var argsGet = {
	headers: Headers
};

function getDate(data){
	var d1= data;
	d1=d1.split('-');
	
	d1= new Date(d1[0],d1[1]-1,d1[2]);
	return d1;
}

client.get(getUrl, argsGet, function (data, response) {
    var result={};
    var currentDate = new Date();

    var i;
    for(i=0;i<data.length; i++){
    	var startDate = getDate(data[i].startDate);
    	var endDate = data[i].endDate;
    	if(endDate!=null)
    		endDate = getDate(endDate);

    	if(startDate< currentDate && (endDate==null || (currentDate < endDate))){
    		if(result[data[i].category]!=null){
    			result[data[i].category]= result[data[i].category] +1;
    		}
    		else{
    			result[data[i].category]= 1;
    		}
    	}
    }
    console.log(JSON.stringify(result));
    var argsPost = {
	    data: JSON.stringify(result),
	    headers: Headers
	};

	client.post(postUrl, argsPost, function (data, response) {
	    console.log(data);    
	});
});