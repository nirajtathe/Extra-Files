var methods= require('./soap.methods');
var events= require('events');
var mongojs= require('mongojs');
const nodemailer = require('nodemailer');

var db = mongojs('PUNITP382938D:27017/fbdi', ['fbdi_schedule']);
var db2 = mongojs('PUNITP382938D:27017/fbdi', ['fbdi_data']);
var currentResult = new events.EventEmitter();

//globalStatus holds the current status
var globalStatusAll= require('../public/config').globalStatus;
var {emailHost, emailFrom, emailTo, emailSubject} = require('../public/config');

var number=34;//remove number dependency ; add dynamic file name

let transporter = nodemailer.createTransport({
    host: emailHost,
    ignoreTLS: true,
    secure: false
});

let mailOptions = {
    from: emailFrom,
    to: emailTo,
    subject: emailSubject
};

var execute = function(wfName){
  globalStatus = globalStatusAll.filter((allData) => (allData.wf === wfName));
  if(globalStatus=== null || globalStatus === undefined || globalStatus.length===0){
    globalStatusAll.push({wf: wfName});
    globalStatus = globalStatusAll.filter((allData) => (allData.wf === wfName));
  }

  var num;
  var jobName;
  var pkgName;
  db2.fbdi_data.find({'Workflow':wfName}, function(err, docs){
    db2.close();
    if(err){
      globalStatus[0].status={'isError': true,'errorMessage':'Error during fetching data for "num"',
                     'error': err};//remove err object
      currentResult.emit('getCurrentResult');
      return;
    }
    //console.log(docs);
    if(docs.length=== 0){
      globalStatus[0].status={'isError': true,'errorMessage':'No data available for wf: '+wfName,
                     'error': err};
      currentResult.emit('getCurrentResult');
      return;
    }
    num= docs[0].num;
    jobName = docs[0].JobName;
    pkgName = docs[0].Package;

  });

  db.fbdi_schedule.find({'wf': wfName},function (err, docs) {
      db.close();
      if(err){
        globalStatus[0].status={'isError': true,'errorMessage':'Error in wf name', 'error': err};//remove err object
        currentResult.emit('getCurrentResult');
        //return globalStatus;
        return;
      }
      //considering it will return only one document back
      var fileLoc = docs[0].param.zipFile;
      var params = docs[0].param.submitParams;
      var ucm = docs[0].param.ucm;
      if(typeof fileLoc !== 'string' || fileLoc.length===0 || params.length === 0){
        globalStatus[0].status={'isError': true,'errorMessage':'Error in fileLocation or submit params', 'error':'No valid arguments available to proceed'};
        currentResult.emit('getCurrentResult');
        //return globalStatus;
        return;
      }
      //start executing => all the fbdi operations
      //op1: File uploadFileToUcm
      globalStatus[0].status={'isError': false, successMessage:"Execution started"};
      currentResult.emit('getCurrentResult');

      uploadFile("RemoteFile: "+fileLoc, number, ucm, pkgName, jobName , params);
      //upload ucm completed here

  });//close 1st db callback

}

function uploadFile(fileLoc, ucm, num, pkgName, jobName , params){
  var path = require('path');
  var filename = path.basename(fileLoc);
  var fileD =  path.basename(fileLoc, '.zip');
  methods.uploadFileToUcm(fileLoc, filename, 'zip', fileD,
          fileD,'scm_impl', ucm, 'FAFusionImportExport',function(err,uploadResult){
          if(err){
             globalStatus[0].status={'isError': true,'errorMessage':'Error in upload to UCM', 'error': err};
             currentResult.emit('getCurrentResult');
             //return globalStatus;
             return;
           }
           globalStatus[0].status={'isError': false,'successMessage':'Upload to UCM was successfully executed',
                        'result': uploadResult};
           currentResult.emit('getCurrentResult');
           //console.log("Upload was successfully executed: "+result);

           submitJob1st(num, uploadResult, pkgName, jobName , params);
    });
}

function submitJob1st(num, uploadResult, pkgName, jobName , params){
    methods.submitEssJobStatus('oracle/apps/ess/financials/commonModules/shared/common/interfaceLoader',
         'InterfaceLoaderController',[num, uploadResult.result], function(err,submitFirstResult){
           if(err){
             globalStatus[0].status={'isError': true,'errorMessage':'Error in Submit Ess job', 'error': err};
             currentResult.emit('getCurrentResult');
             //return globalStatus;
             return;
           }
           globalStatus[0].status={'isError': false,'successMessage':'1st: Submit ESS Job was successfully executed',
                         'result': submitFirstResult};
           currentResult.emit('getCurrentResult');
           //console.log("Submit ESS Job was successfully executed: "+result);

           //get status result data : "complete" or "error"
           var resultData="";
           var flag=false;
           var timer = setInterval(()=>{
              //1st get Method()
              getStatus(submitFirstResult).then(
                 (result)=> {
                     flag=result.flag;
                     if(flag === true){
                       resultData= result.resultData;
                        clearInterval(timer);
                        if(resultData === 'SUCCEEDED'){
                          //op4: 2nd Submit Ess job
                          globalStatus[0].status={'isError': false,'successMessage':'1st: Get Status was successfully executed',
                                        'result': resultData};
                          currentResult.emit('getCurrentResult');
                          submitJob2nd(pkgName, jobName , params);
                        }//if end: 1st get result "SUCCEEDED"
                        else if(resultData === 'ERROR'){
                          globalStatus[0].status={'isError': true,'errorMessage':'1st: Get Status has thrown an error',
                                        'result': resultData};
                          currentResult.emit('getCurrentResult');
                          console.log("Something went wrong in 1st submit and 1st get status");
                        }
                     }
                 }
              );
         },20000);
  });
}

function getStatus(submitResult){
    return new Promise ((resolve,reject)=>{
          var flag=false;
          methods.getJobStatus(submitResult.result, function(err, getResult){
            if(err){
              resultData="Error";
              globalStatus[0].status={'isError': true,'errorMessage':'Error in get Status job', 'error': err};
              currentResult.emit('getCurrentResult');
              flag=true;
              var res= {flag,err};
              resolve(res);
            }
            resultData=getResult.result;// getResult: {result : "ERROR" OR "SUCCEEDED"}
            //console.log("result get status (getResult.result): "+ JSON.stringify(resultData));
            if(resultData==='SUCCEEDED'){
              //globalStatus[0].status={'isError': false,'successMessage':'Get Job status was successfully executed',
              //              'result': getResult};
              //currentResult.emit('getCurrentResult');
              flag=true;
              var res= {flag,resultData};
              resolve(res);
              //break;
            }
            if(resultData==='ERROR'){
              // globalStatus[0].status={'isError': true,'errorMessage':'Error in get Status job', 'error': getResult}
              // currentResult.emit('getCurrentResult');
              flag=true;
              var res= {flag,resultData};
              resolve(res);
            }
            resolve({flag});
        });
    });
}

function submitJob2nd(pkgName, jobName , params){
    methods.submitEssJobStatus(pkgName, jobName , params, function(err,submitSecondResult){
         if(err){
           globalStatus[0].status={'isError': true,'errorMessage':'Error in Submit Ess job', 'error': err};
           currentResult.emit('getCurrentResult');
           //return globalStatus;
           return;
         }
         globalStatus[0].status={'isError': false,'successMessage':'2nd: Submit ESS Job was successfully executed',
                       'result': submitSecondResult};
         currentResult.emit('getCurrentResult');
         //console.log("Submit ESS Job was successfully executed: "+result);

         //get status result data : "complete" or "error"
         //op3: get Status 1st time in loop
         var resultData="";
         var flag=false;
         var timer = setInterval(()=>{
            //1st get Method()
            getStatus(submitSecondResult).then(
               (result)=> {
                   flag=result.flag;
                   if(flag === true){
                     resultData= result.resultData;
                      clearInterval(timer);
                      if(resultData === 'SUCCEEDED'){
                        //op4: 2nd Submit Ess job
                        globalStatus[0].status={'isError': false,'successMessage':'2nd: Get Status Job was successfully executed',
                                      'result': resultData};
                        currentResult.emit('getCurrentResult');
                        console.log("Web service call was successfully executed.");

                        //sending an email if every ws call was successful
                        mailOptions.text = "Hi,\n\nThis is an alert mail.\nData is successfull uploaded to cloud.\nYou can login to cloud and verify if required.\nThank you.\n\nAutomated System Mail";
                        transporter.sendMail(mailOptions, (error, info) => {
                            if (error) {
                                return console.log(error);
                            }
                            console.log('Message sent.');//, info.messageId);
                        });

                      }//if end: 1st get result "SUCCEEDED"
                      else if(resultData === 'ERROR'){
                        globalStatus[0].status={'isError': true,'errorMessage':'1st: Get Status has thrown an error',
                                      'result': resultData};
                        currentResult.emit('getCurrentResult');
                        console.log("Something went wrong in 2nd get status");
                      }
                   }
               }
            );
        },20000);

   });
}

//email sent twice ; resolve it
currentResult.on('getCurrentResult',()=>{
  console.log("Event Current Data: "+ JSON.stringify(globalStatus[0],undefined,2));

  //sending an email if there is an error
  if(globalStatus.isError === true){
    mailOptions.text = "Hi,\n\nThis is an alert mail.\nThere is an error while executing scheduled workflow.\nPlease check!!\n\nAutomated System Mail";
    mailOptions.attachments =[{
            filename: 'errorMessage.txt',
            content: JSON.stringify(globalStatus[0],undefined,2)
    }];

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return console.log(error);
        }
        console.log('Message sent.');//, info.messageId);
    });
  }
});

//execute('Create Inv');
module.exports.executeAllWebservice= execute;

//Unhandled below errors:=>
//cloud timeout errorMessage
/*"error": {
  "code": "ESOCKETTIMEDOUT",
  "connect": false
}*/

//random exception while Execution :in first call only
/*
Unable to connect to cloud. Maybe authentication header has some problems.
Event Current Data: {
  "isError": true,
  "errorMessage": "Error in upload to UCM",
  "error": {
    "code": "ECONNRESET"
  }
}
*/
