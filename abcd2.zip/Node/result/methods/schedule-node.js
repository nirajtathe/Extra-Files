var schedule = require('node-schedule');
var executeWS= require('./methods/callAllWs').executeAllWebservice;
var mongojs= require('mongojs');
var db = mongojs('PUNITP382938D:27017/fbdi', ['fbdi_schedule']);
// 4 parameters are not accepted in "dayOfWeek"; it wont execute
var jobs= require('../public/config').jobs;

function scheduleJob(wf,exeData,uname){
  var wfExists= jobs.filter((k) => (k.wf=== wf && k.uname === uname));
  if(wfExists=== null || wfExists === undefined || wfExists.length===0){
    var newJob = schedule.scheduleJob(wf+'-job', exeData, function(workFlow){
      console.log('Executing the call :'+workFlow+' '+new Date());
      executeWS(workFlow);
    }.bind(null,wf,uname));
    console.log('wf done');
    jobs.push({'wf':wf, 'job': newJob,'uname': uname});
  }else{
    console.log('wf exists: '+ JSON.stringify(wfExists));
  }
}

function deleteJob(wf){
  var result=false;
  for(var i=0;i<jobs.length; i++){
    var k=jobs[i].wf;
    if(data == k){
      jobs[i].job.cancel();
      console.log('Canceled scheduled job is : '+ JSON.stringify(jobs[i].job));
      jobs.splice(i,1);
      result=true;
      break;
    }
  }
  return result; //or msg with no such job exists
}

scheduleJob('Create Inv', {"hour" : 14,"minute" : 41,"dayOfWeek" : [ 3,4]}, 'asmi.gandhi');
//scheduleJob('Create Inv', {"hour" : 11,"minute" : 43,"dayOfWeek" : [ 0, 1, 2, 3]});
/*
db.fbdi_schedule.find(function (err, docs) {
    if(err){
      return console.log(err);
    }
    data = docs;
    for(var i=0;i<data.length;i++){
      var exeData = data[i].exe_at;
      var wfExists= jobs.filter((k) => k.wf=== data[i].wf);
      if(wfExists=== null || wfExists === undefined || wfExists.length===0){
        var wf=data[i].wf;
        scheduleJob(wf,exeData);
      }else{
        console.log('wf exists: '+ wfExists);
      }
    }
});
*/

/*
setTimeout(()=>{
  data="Create Inv";
  console.log("total jobs before: "+ JSON.stringify(jobs,undefined,2));
  for(var i=0;i<jobs.length; i++){
    var k=jobs[i].wf;
    if(data == k){
      jobs[i].job.cancel();
      console.log('Canceled scheduled job is : '+ JSON.stringify(jobs[i].job));
      jobs.splice(i,1);
      break;
    }
  }
  console.log("total jobs after : "+ JSON.stringify(jobs,undefined,2));
}, 6000);
*/
