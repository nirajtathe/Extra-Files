var config= require('../public/config');
var request = require('request');
var soap = require('soap');
var fs= require('fs');

function soap_request(){
  var url = config.URL+'/publicFinancialCommonErpIntegration/ErpIntegrationService?WSDL';
  let request_with_defaults = request.defaults({
    'proxy': 'http://10.76.242.101:80',//'http://10.74.91.103:80',
    'timeout': 50000,
    'connection': 'keep-alive',
    'Content-Type': 'text/xml;charset=UTF-8',
    'gzip': true,
    'deflate': true
  });
  var auth = "Basic " + new Buffer( config.USERNAME + ":" + config.PASSWORD ).toString('base64');
  return [url,request_with_defaults,auth];
}

module.exports = {

  getJobStatus : function (requestIdInput,callback) {
      soap_param= soap_request();
      var url= soap_param[0];
      let request_with_defaults = soap_param[1];
      var auth = soap_param[2];

      let soap_client_options = {
        'request': request_with_defaults,
        overridePromiseSuffix: 'getESSJobStatus'
      };

      var args = {
        requestId: requestIdInput//'1406303' //eneter request is and check by running the program
      };
      soap.createClient(url, soap_client_options , function(err, client) {
        if(err){
          console.log('Unable to connect to cloud. Maybe authentication header has some problems.');
          //res.end(JSON.stringify(err));
          callback(err);
          return;
        }
        client.addHttpHeader('Authorization', auth);

    	  client.getESSJobStatus(args, function(err, result) {
            if(err){
              console.log('Error occured');
        	//res.end(JSON.stringify(err));
              callback(err);
            }else{
      	    fs.writeFileSync('./result/getESSJobStatus.json',JSON.stringify(result));
              console.log('Successful soap request.');
              //res.end(JSON.stringify(result));
              callback(undefined, result);
            }
        });

      });
  },

  submitEssJobStatus: function (jobPackageInput, jobNameInput, paramListInput,callback){
    soap_param= soap_request();
    var url= soap_param[0];
    let request_with_defaults = soap_param[1];
    var auth = soap_param[2];

    let soap_client_options = {
      'request': request_with_defaults,
      overridePromiseSuffix: 'submitESSJobRequest'
    };
    var args = {
      jobPackageName : jobPackageInput,
      jobDefinitionName : jobNameInput,
      paramList : paramListInput
    };
    soap.createClient(url, soap_client_options , function(err, client) {
      if(err){
        console.log('Unable to connect to cloud. Maybe authentication header has some problems.');
        //res.end(JSON.stringify(err));
        callback(err);
        return;
      }
      client.addHttpHeader('Authorization', auth);

      client.submitESSJobRequest(args, function(err, result) {
          if(err){
            console.log('Error occured');
            //res.end(JSON.stringify(err));
            callback(err);
          }else{
            fs.writeFileSync('./result/submitESSJobRequest.json',JSON.stringify(result));
            console.log('Successful soap request.');
            //res.end(JSON.stringify(result));
            callback(undefined, result);
          }
      });

    });

  },

  uploadFileToUcm: function(fileLocation, fileName, contentType, docTitle, docName,
                            docAuthor, ucmAccountInfo, ucmSecurityGroup, callback) {
      soap_param= soap_request();
      var url= soap_param[0];
      let request_with_defaults = soap_param[1];
      var auth = soap_param[2];

      let soap_client_options = {
        'request': request_with_defaults,
        escapeXML:false,
        overridePromiseSuffix: 'uploadFileToUcm'
      };
      var byteArray;
      if(fileLocation.startsWith("RemoteFile:"))
        const { URL } = require('url');
        fileLocation = fileLocation.split('RemoteFile: ');
        const fileUrl = new URL(fileLocation[1]);

        byteArray = fs.readFileSync(fileUrl).toString('base64');
        //console.log(data.toString());
      }else{
        byteArray = fs.readFileSync(fileLocation).toString('base64');//"utf8" use for normal
      }

      var args = {
        "document": "<erp:Content xmlns:erp=\"http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/\" >"
      	+byteArray
      	+"</erp:Content> <erp:FileName xmlns:erp=\"http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/\" >"
      	+fileName
      	+"</erp:FileName> <erp:ContentType xmlns:erp=\"http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/\" >"
      	+contentType
      	+"</erp:ContentType> <erp:DocumentTitle xmlns:erp=\"http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/\" >"
      	+docTitle
      	+"</erp:DocumentTitle> <erp:DocumentAuthor xmlns:erp=\"http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/\" >"
      	+docAuthor
      	+"</erp:DocumentAuthor> <erp:DocumentSecurityGroup xmlns:erp=\"http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/\" >"
      	+ucmSecurityGroup
      	+"</erp:DocumentSecurityGroup> <erp:DocumentAccount xmlns:erp=\"http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/\" >"
      	+ucmAccountInfo
      	+"</erp:DocumentAccount> <erp:DocumentName xmlns:erp=\"http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/\" >"
      	+docName
      	+"</erp:DocumentName>"
      }
      var resultD;
      soap.createClient(url, soap_client_options , function(err, client) {
        if(err){
          console.log('Unable to connect to cloud. Maybe authentication header has some problems.');
          //res.end(JSON.stringify(err));
          callback(err);
          return;
        }
        client.addHttpHeader('Authorization', auth);
        client.addHttpHeader('Content-Length', args.length);

    	  client.uploadFileToUcm(args, function(err, result) {
            if(err){
              console.log('Error occured');
              //res.end(JSON.stringify(err));
              callback(err);
            }else{
              fs.writeFileSync('./result/uploadFileToUcm.json',JSON.stringify(result));
              console.log('Successful soap request.');
              //res.end(JSON.stringify(result));
              callback(undefined, result);
            }
        });

      });
  },

  downloadESSJobExecutionDetails: function(requestIdInput, callback) {
      soap_param= soap_request();
      var url= soap_param[0];
      let request_with_defaults = soap_param[1];
      var auth = soap_param[2];

      let soap_client_options = {
        'request': request_with_defaults,
        overridePromiseSuffix: 'downloadESSJobExecutionDetails',
        ignoredNamespaces: true
      };

      var args = {
        requestId : requestIdInput,//'1406303' //eneter request is and check by running the program
        fileType : 'zip'
      };

      soap.createClient(url, soap_client_options , function(err, client) {
        if(err){
          console.log('Unable to connect to cloud. Maybe authentication header has some problems.');
          //res.end(JSON.stringify(err));
          callback(err);
          return;
        }
        client.addHttpHeader('Authorization', auth);
        dd=null;
    	  client.downloadESSJobExecutionDetails(args, function(err, result) {
            if(err){
        	console.log('Error occured');
              //res.end(JSON.stringify(err));
              callback(err);
        	}else{
              //console.log(JSON.stringify(client.response));
              fs.writeFileSync('./result/downloadESSJobExecutionDetails.json',JSON.stringify(result));
              console.log('Successful soap request.');
              //dd=JSON.stringify(result);
              //res.end(JSON.stringify(dd));
              //res.end(JSON.stringify(result));
              callback(undefined, result);
            }
        },{exchangeId: 1234});
        client.on('response',(data,IncomingMessage)=>{
            console.log("Response data herer :  ************************    "+data);
            console.log("entire msg : "+JSON.stringify(IncomingMessage) );
        },{exchangeId: 1234});


      });
  }
}
