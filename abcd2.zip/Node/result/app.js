var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var jwt = require('jsonwebtoken');
var db = require('./database/user_db');
var url = require('url');
var winston = require('winston');
var methods = require('./methods/soap.methods');
var config = require('./public/config');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(logErrors)
app.use(clientErrorHandler)
app.use(errorHandler)


function logErrors(err, req, res, next) {
  console.error(err.stack)
  next(err)
}


var appRouter = require('./routes/soap.ws')();
app.use("/api", appRouter);

app.get("/", function (req, res) {
  res.send("<h2>Hi,<br> Welcome to WS API</h2>"
    + "<br><h3><a href='http://localhost:3000/api/upload'>Get Status</a></h3>"
    + "<br><h3><a href='http://localhost:3000/api/submitEss'>Get Status</a></h3>"
    + "<br><h3><a href='http://localhost:3000/api/getStatus'>Get Status</a></h3>"
    + "<br><h3><a href='http://localhost:3000/api/downloadLog'>Get Status</a></h3>");
});


function clientErrorHandler(err, req, res, next) {
  if (req.xhr) {
    res.status(500).send({ error: 'Something failed!' })
  } else {
    next(err)
  }
}

function errorHandler(err, req, res, next) {
  res.status(500)
  res.render('error', { error: err })
}


app.use(function (req, res, next) {
  console.log(1);
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS, DELETE, GET");
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization, IPAddress");
  res.header("Access-Control-Allow-Credentials", true);
  next();
});

app.use(function (req, res, next) {
  console.log(2);
  var urls = url.parse(req.url).pathname;
  console.log(urls);
  if (urls.startsWith("/users/login") || req.method == 'OPTIONS' 
  || urls.startsWith("/download") || urls.startsWith("/current") ) {
    next();
  } else {
    authenticate(req, (status, message) => {
      if (status === 'err' && message === 'Bad Request!!') {
        logger.error('No authentication header passed');
        return res.status(403).status('Bad Request');
      } else if (status === 'err' && message === 'Unauthenticated user!') {
        logger.error('Cannot find username');
        return res.status(403).status('Unauthenticated Request');
      } else if (status === 'err' && message === 'Unauthenticated user') {
        logger.error('Incorrect credentials');
        return res.status(403).status('Unauthenticated user');
      } else if (status === 'suc') {

        role = message.split(":")[0];
        user = message.split(":")[1];
        logger.info('Authenticated user\'s cred! -> user = ' + user + ' , role = ' + role + ' asking for url: ' + req.url);

        if (urls.startsWith("/wfdetails/addwf") || urls.startsWith("/wfdetails/delete") || urls.startsWith("/users/add") || urls.startsWith("/wfdetails/all") || urls.startsWith("/users/reset") || urls.startsWith("/users/delete") || urls.startsWith("/users/all")) {
          if (role === 'Admin') {
            next();
          } else {
            logger.error(user + ' asking for admin data! unauthorized!');
            return res.status(401).status('Unauthorized user');
          }
        } else if (urls.startsWith("/users/me") || urls.startsWith("/schd") || urls.startsWith("/prev") ||
          urls.startsWith("/getStatus") || urls.startsWith("/downloadLog") ||
          urls.startsWith("/upload") || urls.startsWith("/submitEss")) {
          next();
        }
      }
    });


  }
});

let username = '_';
let ip = '';
const logFormatter = function (options) {
  // Return string will be passed to logger.

  return options.timestamp() + ` => ` +
    options.level.toUpperCase() + ` => ` +
    //ip + ` => ` +
    username + ` => ` +
    (options.message ? options.message : ``) +
    (options.meta && Object.keys(options.meta).length ? `\n\t` + JSON.stringify(options.meta) : ``);
};

const timestamp = function () {
  const d = new Date();
  return d.getDate() + `-` + (d.getMonth() + 1) + `-` + d.getFullYear() + ` ` + d.getHours() + `:` + d.getMinutes() + `:` + d.getSeconds();
};

const logger = new (winston.Logger)({
  transports: [
    new (winston.transports.File)({
      timestamp: timestamp,
      formatter: logFormatter,
      level: `silly`,
      name: `logs`,
      filename: `logs.log`,
      json: false,  // set json:false on the file transport(s)
    })
  ]
});


function authenticate(req, callback) {
  auth = req.header("Authorization");
  if (!auth) {
    callback('err', "Bad Request!!");
  }

  usern = jwt.decode(auth, 'adjkfgjkdhgkjdhgjkdfhgjkdfhgjkdfghkjdfhgkjdfghjkdfghjkdfhgkjdf564sd5f432465444g');

  if (!usern) {
    callback('err', "Unauthenticated user!");
  }
  db.getRole(logger, usern, function (err, user) {
    if (err == 'success') {
      callback('suc', user + ':' + usern);
      username = usern;
    } else {
      callback('err', "Unauthenticated user");
    }
  });
};

app.set('port', process.env.PORT || 3000);
app.set('logger', logger);

app.use(require('./routes/previous'));
app.use(require('./routes/users'));
app.use(require('./routes/upcoming'));
app.use(require('./routes/all_data'));

var server = app.listen(app.get('port'), function () {
  console.log('Listening on port ' + app.get('port'));
  logger.info('Server started on ' + app.get('port'))
});
