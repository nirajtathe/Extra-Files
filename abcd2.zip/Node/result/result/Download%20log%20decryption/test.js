fs= require('fs');
var unidecode = require('unidecode');

data= fs.readFileSync('test.txt');
console.log(unidecode(data));
//fs.writeFileSync('testRes.txt',);
