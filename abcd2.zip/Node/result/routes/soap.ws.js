var express=require('express');
var methods= require('../methods/soap.methods');
var multer = require('multer');
var globalStatus= require('../public/config').globalStatus;
var currentJobs= require('../public/config').currentJobs;
var jobs= require('../public/config').jobs;
var executeCurrentJob = require('../methods/current.jobs').executeCurrentWebservice;
var routes= function(){
  appRouter=express.Router();

  appRouter.route("/upload")
    .get(function(req,res){
      logger = req.app.get('logger');
      logger.info('uploadFileToUcm (get) webservice is called!');
      methods.uploadFileToUcm('D:\\UI Development\\Node\\FBDI MEAN Stack\\abc.zip', 'abc15.zip', 'zip', 'abc15', 'abc15',
                     'scm_impl', 'scm/inventoryTransaction/import', 'FAFusionImportExport',
                     function(err,result){
                       if(err){
                         res.json({'message':'Error in upload call', 'err':err});
                       }else{
                         res.json(result);
                       }
                     });
    })
    .post(function(req,res){
      //fileLocation, fileName, contentType, docTitle, docName,
            //docAuthor, ucmAccountInfo, ucmSecurityGroup
      logger = req.app.get('logger');
      logger.info('uploadFileToUcm (post) webservice is called!');
      methods.uploadFileToUcm(req.body.fileLocation ,req.body.fileName , req.body.contentType ,
                          req.body.docTitle ,req.body.docName ,req.body.docAuthor ,req.body.ucmAccountInfo,
                          req.body.ucmSecurityGroup,
                          function(err,result){
                            if(err){
                              res.json({'message':'Error in upload call', 'err':err});
                            }else{
                              res.json(result);
                            }
                          });
    });

  appRouter.route("/submitEss")
    .get(function(req,res){
      logger = req.app.get('logger');
      logger.info('submitEss (get) webservice is called!');
      methods.submitEssJobStatus('oracle/apps/ess/financials/commonModules/shared/common/interfaceLoader',
                          'InterfaceLoaderController','33', '2350852',
                          function(err,result){
                            if(err){
                              res.json({'message':'Error in submitEssJobStatus call', 'err':err});
                            }else{
                              res.json(result);
                            }
                          });
    })
    .post(function(req,res){
      //jobPackageInput, jobNameInput, paramListInput
      logger = req.app.get('logger');
      logger.info('submitEss (post) webservice is called!');
      methods.submitEssJobStatus(req.body.jobPackageInput ,req.body.jobNameInput, req.body.paramListInput,
                        function(err,result){
                          if(err){
                            res.json({'message':'Error in submitEssJobStatus call', 'err':err});
                          }else{
                            res.json(result);
                          }
                        });
    });

  appRouter.route("/getStatus")
    .get(function(req,res){
        logger = req.app.get('logger');
        logger.info('getStatus (get) webservice is called!');
        methods.getJobStatus('1418050',function(err,result){
          if(err){
            res.json({'message':'Error in get status call', 'err':err});
          }else{
            res.json(result);
          }
        });
    })
    .post(function(req,res){
      //requestId is expected inside body
      //methods.getJobStatus(res,req.body.requestId);
      logger = req.app.get('logger');
      logger.info('getStatus (post) webservice is called!');
      methods.getJobStatus(req.body.requestId,function(err,result){
        if(err){
          res.json({'message':'Error in get status call', 'err':err});
        }else{
          res.json(result);
        }
      });
    });

  appRouter.route("/downloadLog")
    .get(function(req,res){
      logger = req.app.get('logger');
      logger.info('downloadLog (get with static data) webservice is called!');
      methods.downloadESSJobExecutionDetails('1418050',
            function(err,result){
              if(err){
                res.json({'message':'Error in downloadESSJobExecutionDetails call', 'err':err});
              }else{
                res.json(result);
              }
            });
    })
    .post(function(req,res){
      //requestId is expected inside body
      logger = req.app.get('logger');
      logger.info('downloadLog (post) webservice is called!');
      methods.downloadESSJobExecutionDetails(req.body.requestId,
            function(err,result){
              if(err){
                res.json({'message':'Error in downloadESSJobExecutionDetails call', 'err':err});
              }else{
                res.json(result);
              }
            });
    });

  appRouter.route("/globalStatus")
      .get(function(req,res){
        logger = req.app.get('logger');
        wfName = req.body.requestId;
        logger.info('Fetching status for scheduled job (workflow name: '+wfName+')');
        jobStatus= globalStatus.filter((job) => (wfName === job.wf));
        if(jobStatus=== null || jobStatus === undefined || jobStatus.length===0){
          res.json({result: 'No job scheduled for given workflow'})
        }else{
          res.json(jobStatus[0]);
        }

      });

  appRouter.route("/exeNow")
      .get(function(req,res){
        logger = req.app.get('logger');
        wfName = req.params.wf;
        username = req.params.username;
        logger.info('Starting the execution of workflow : '+wfName);
        executeCurrentJob(wfName,username);
        res.send('Execution started');
      });

  appRouter.route("/currentJobs")
      .get(function(req,res){
        logger = req.app.get('logger');
        username = req.params.username;
        logger.info('Fethcing currenltly executing job for specific user: '+username);

        jobDetails= currentJobs.filter((job) => (username === job.username));
        if(jobDetails=== null || jobDetails === undefined || jobDetails.length===0){
          res.json({result: 'No such Job running'});
        }else{
          res.json(jobDetails);
        }
      });

  return appRouter;
};

module.exports = routes;
