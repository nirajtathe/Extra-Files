var express = require('express');
var db = require('../database/upcoming_db.js')
var fs = require('fs');
var path = require("path");
var router = express.Router()
var jwt = require('jsonwebtoken');


/*
  schd execution : /schd/username
  input username
  output raw data
*/
router.get('/schd/:username', function(req, resp){
  username = req.params.username;
  logger = req.app.get('logger');
  logger.info('get schd process of : '+username);
  db.schdDetails(logger,username, function(status, data){
    if(status=='fail'){
      resp.status(404).end("Error");
    }else{
      resp.status(200).send(data)
  }});
});

/*
  add schd
  input
*/
module.exports = router;
