var express = require('express');
var app = express();
var db = require('../database/all_data_db.js')
var fs = require('fs');
var path = require("path");
var router = express.Router();
var bodyParser = require('body-parser');
var jwt = require('jsonwebtoken');

app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: false })); // support encoded bodies


router.get('/wfdetails/all', function(req, resp){
  logger = req.app.get('logger');
  logger.info('get all wf');
  db.getAllWfDetails(logger,function(status, data){
      resp.send(data);
  })
});


router.delete('/wfdetails/delete/:wf', function(req, resp){
  
  var wf = req.params.wf;
  logger = req.app.get('logger');
  logger.info('get wf: '+wf);
  db.deleteWf(logger,wf, function(status, data, last){
      resp.send(status);
  })
});

router.post('/wfdetails/addwf', function(req, resp){
  var wf = req.body.Workflow;
  var package = req.body.package;
  var job = req.body.JobName;
  var num = req.body.num;
  logger = req.app.get('logger');
  logger.info('add wf: '+wf+'  '+package+'  '+job+'  '+num);
  db.createWf(logger,job, package, num, wf, function(status, data){
      resp.send(data);
  })
});

module.exports = router;
