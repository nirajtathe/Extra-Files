var express = require('express');
var db = require('../database/prev_db.js')
var fs = require('fs');
var path = require("path");
var router = express.Router()
var jwt = require('jsonwebtoken');


/*
  previous execution : /prev/username
  input username
  output raw data
*/
router.get('/prev/:username', function(req, resp){
  username = req.params.username;
  logger = req.app.get('logger');
  logger.info('get Prev exe data of: '+username);
  db.exeDetails(logger,username, function(status, data){
    if(status=='fail'){
      resp.send(data)
    }else{
      for(var i=0;i<data.length;i++){

        var b64string = data[i].cloudlog_1;
        fs.writeFileSync('cloudlog_1_'+username+'.zip', b64string, {encoding: 'base64'});
        data[i].cloudlog_1= path.resolve('cloudlog_1_'+username+'.zip');

        var b64string = data[i].cloudlog_2;
        fs.writeFileSync('cloudlog_2_'+username+'.zip', b64string, {encoding: 'base64'});
        data[i].cloudlog_2= path.resolve('cloudlog_2_'+username+'.zip');

        var b64string = data[i].exe_log;
        fs.writeFileSync('exe_log_'+username+'.zip', b64string, {encoding: 'base64'});
        data[i].exe_log= path.resolve('exe_log_'+username+'.zip');
      }
      resp.send(data)
    }
  })
})

/*
  add execution
  input
*/


module.exports = router;
