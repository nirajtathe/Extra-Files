var express = require('express');
var app = express();
var db = require('../database/user_db.js')
var fs = require('fs');
var path = require("path");
var router = express.Router();
var bodyParser = require('body-parser');
var jwt = require('jsonwebtoken');

app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: false })); // support encoded bodies

router.post('/download', function(req, res){
  console.log(req.body.filePth);
  logger = req.app.get('logger');
  file = req.body.filePth;
  logger.info('Downloading file from : '+file);
  res.download(file);
});

/*
  login user  ->   /users/add
  username, password
  role/error
*/

router.post('/users/login', function (req, res) {
  logger = req.app.get('logger');
  var username = req.body.username;
  var password = req.body.password;
  logger.info(username+' trying to login !');
  db.authUser(logger, username, password, function (status, user) {
    if (status === 'success') {
      var obj = new Object();
      obj.role = user[0].role;
      obj.token = jwt.sign(username, 'adjkfgjkdhgkjdhgjkdfhgjkdfhgjkdfghkjdfhgkjdfghjkdfghjkdfhgkjdf564sd5f432465444g');
      logger.info(username+' logged in!');      
      res.status(200).send(obj);
    } else {
      logger.info(username+ 'logged in failed');
      var obj = new Object();
      obj.error = 'Invalid User!';
      res.status(403).send(obj);
      
    }
  });
});


/*
  reset password ->
  username password
  success/error
*/
router.post('/users/reset', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  logger = req.app.get('logger');
  logger.info('resetting user password : '+username);
  db.resetPassword(logger, username, password, function (err, doc, lastErrorObject) {
    logger.info('password reset for : '+username);
    res.send(err);
  });
});


/*
  create iser ->
  username, password, account, role, manager
  status
*/
router.post('/users/add', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  var account = req.body.account;
  var role = req.body.role;
  var name = req.body.name;
  var manager = req.body.manager;
  logger = req.app.get('logger');
  logger.info('add user : '+username);
  db.createUser(logger, username, password, account, role, name, manager, function (status, save) {
    logger.info(status+" "+save);
    res.send(status);
  });
});


/*
  delete user
  username
  status
*/
router.get('/users/delete/:username', function (req, resp) {
  username = req.params.username;
  logger = req.app.get('logger');
  logger.info('delete user: '+username);
  db.deleteUser(logger, username, function (err, doc, lastErrorObject) {
    logger.info('status: '+err);
    resp.send(err)
  })
});


/*
  get user data
  username
  status
*/
router.get('/users/me/:username', function (req, resp) {
  username = req.params.username;
  logger = req.app.get('logger');
  logger.info('get user profile: '+username);
  db.getUser(logger, username, function (status, data) {
    resp.send(data);
  })
});



/*
  get all user data
  username
  status
*/
router.get('/users/all', function (req, resp) {
  logger = req.app.get('logger');
  logger.info('get all users');
  db.getAllUser(logger, function (status, data) {
    resp.send(data);
  })
});



module.exports = router;
