var express = require('express');
var app = express();
var fs = require('fs');

app.get('/hello', (rq, res) => {
    file = 'http:\\\\ad.infosys.com\\storage\\CHD\\SEZ\\ORC\\ORACTCGZ\\logs.log';
    t =  fs.readFileSync(file);
    console.log(t);
});

app.listen(3001);
