module.exports = {
 PORT : 3000,
 URL: 'https://adc-fap0960-fin.oracledemos.com:443',
 USERNAME: 'scm_impl',
 PASSWORD: 'StA69495',//'AdA37586',//'dpb98445'//'cVM58543'
 jobs: [],
 globalStatus: [],
 currentJobs: [],
 emailHost: '192.168.170.26',
 emailFrom: 'Niraj.Tathe@test.com',
 emailTo: 'Niraj.Tathe@test.com',
 emailSubject: 'Alert from FBDI'
};
