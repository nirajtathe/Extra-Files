var mongojs = require('mongojs');
var dburl = 'localhost/fbdi';
var collection = ['fbdi_exe', 'fbdi_schedule', 'fbdi_users', 'fbdi_data'];
var db = mongojs(dburl, collection);

module.exports = {

    /**
      * get schd details
      * @Input username
      * @Output complete schd details
      *
      */
    schdDetails: function (logger,username, callback) {
        db.fbdi_schedule.find({
            'uname': username
        }, { _id: 0 }, function (err, user) {
            logger.info('schdDetails--> fbdi_schedule.find func(): '+'   error:'+JSON.stringify(err)+'   data:'+JSON.stringify(user));
            if (err || !user || user.length == 0) {
                return callback('fail', err);
            } else {
                return callback('success', user)
            }
        }
        );
    }

}
