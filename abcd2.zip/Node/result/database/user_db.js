var mongojs = require('mongojs');
var dburl = 'localhost/fbdi';
var collection = ['fbdi_exe', 'fbdi_schedule', 'fbdi_users', 'fbdi_data'];
var db = mongojs(dburl, collection);


module.exports = {
  /**
    * authenticate user
    * @Input username, password
    * @Output user complete data
    *
    */
  authUser: function (logger,   username, password, callback) {
    db.fbdi_users.find({
      'uname': username,
      'password': password
    }, function (err, user) {
      logger.info('auth user: '+username+'  '+password+'  '+JSON.stringify(user)+' '+JSON.stringify(err));
      if (err || !user || user.length == 0) {
        return callback('fail', err);
      } else {
        return callback('success', user)
      }
    }
    );
  },

  /**
    * getRole of user
    * @Input username
    * @Output user complete data
    *
    */
  getRole: function (logger, username, callback) {
    db.fbdi_users.find({
      'uname': username
    }, { role: 1 }, function (err, user) {
      logger.info('get Role: '+username+' '+JSON.stringify(user)+ '  '+JSON.stringify(err));
      if (err || !user || user.length == 0) {
        return callback('fail', err);
      } else {
        return callback('success', user[0].role)
      }
    }
    );
  },

  /**
    * get user
    * @Input username
    * @Output user complete data
    *
    */
  getUser: function (logger, username, callback) {
    db.fbdi_users.find({
      'uname': username
    }, { _id: 0 }, function (err, user) {
      logger.info('get user: '+JSON.stringify(err)+' '+JSON.stringify(user));
      if (err || !user || user.length == 0) {
        return callback('fail', err);
      } else {
        return callback('success', user)
      }
    }
    );
  },

  /**
    * Create user
    * @Input username, password, account, role, name, manager
    * @Output new user complete data
    *
    */
  createUser: function (logger, username, password, account, role, name, manager, callback) {
    db.fbdi_users.save({
      'uname': username,
      'password': password,
      'account': account,
      'role': role,
      'name': name,
      'manager': manager
    }, function (err, save) {
      logger.info('Create user: '+username+'  '+JSON.stringify(save)+' '+JSON.stringify(err));
      if (err || !save) {
        return callback('fail', err);
      } else {
        return callback('success', save)
      }
    }
    );
  },

  /**
    * reset password
    * @Input username, password
    * @Output new password
    *
    */
  resetPassword: function (logger, username, password, callback) {
    db.fbdi_users.findAndModify({
      query: { 'uname': username },
      update: { $set: { 'password': password } },
      new: false
    },
      function (err, doc, lastErrorObject) {
        logger.info('reset password: '+username+' '+password+ ' '+ JSON.stringify(err)+ '  '+ JSON.stringify(lastErrorObject)+ '  '+ JSON.stringify(doc));
        if (err) {
          return callback('fail');
        } else {
          return callback('success');
        }
      }
    );
  },

  /**
    * Create delete user
    * @Input username
    * @Output send if user data deleted
    *
    */
  deleteUser: function (logger, username, callback) {
    
    db.fbdi_users.remove(
      { 'uname': username },
      function (err, doc, lastErrorObject) {
        logger.info('delete user : '+username+'  result: '+JSON.stringify(err)+'  , '+JSON.stringify(doc)+'   ,   '+JSON.stringify(lastErrorObject));
        return callback(err, doc, lastErrorObject);
      }
    );
  },




  /**
    * get all user details
    * @Output complete schd details
    *
    */
  getAllUser: function (logger, callback) {
    db.fbdi_users.find({}, { _id: 0 }, function (err, user) {
      console.log(logger.toString());
      logger.info('get all users: '+JSON.stringify(err)+'  , '+JSON.stringify(user));
      if (err || !user || user.length == 0) {
        return callback('fail', err);
      } else {
        return callback('success', user)
      }
    }
    );
  }
}
