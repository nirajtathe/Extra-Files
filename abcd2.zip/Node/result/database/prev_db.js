var mongojs = require('mongojs');
var dburl = 'localhost/fbdi';
var collection = ['fbdi_exe', 'fbdi_schedule', 'fbdi_users', 'fbdi_data'];
var db = mongojs(dburl, collection);

module.exports = {


    /**
      * Create new exe entry
      * @Input username
      * @Output send if user data deleted
      *
      */
    execution: function (logger,username, exe_time, wf, cloud, ucm_acc, job_name, job_package, jobid_1, jobid_2, doc_id, result, cloudlog_1, cloudlog_2, exe_log, callback) {
        db.fbdi_exe.save({
            'uname': username,
            'exe_time': exe_time,
            'wf': wf,
            'cloud': cloud,
            'ucm_acc': ucm_acc,
            'job_name': job_name,
            'job_package': job_package,
            'jobid_1': jobid_1,
            'jobid_2': jobid_2,
            'doc_id': doc_id,
            'result': result,
            'cloudlog_1': cloudlog_1,
            'cloudlog_2': cloudlog_2,
            'exe_log': exe_log
        }, function (err, save) {
            logger.info('execution--> fbdi_exe.save func(): '+'   error:'+JSON.stringify(err)+'   data:'+JSON.stringify(save));
            if (err || !save) {
                return callback('fail', err);
            } else {
                return callback('success', save)
            }
        }
        );
    },

    /**
      * get exe details
      * @Input username
      * @Output complete exe details
      *
      */
    exeDetails: function (logger,username, callback) {
        db.fbdi_exe.find({
            'uname': username
        }, { _id: 0 }, function (err, user) {
            logger.info('exeDetails--> fbdi_exe.find func(): '+'   error:'+JSON.stringify(err)+'   data:'+JSON.stringify(user));
            if (err || !user || user.length == 0) {
                return callback('fail', err);
            } else {
                return callback('success', user)
            }
        }
        );
    }

}
