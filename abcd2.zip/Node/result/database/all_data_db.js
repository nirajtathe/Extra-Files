var mongojs = require('mongojs');
var dburl = 'localhost/fbdi';
var collection = ['fbdi_exe', 'fbdi_schedule', 'fbdi_users', 'fbdi_data'];
var db = mongojs(dburl, collection);


module.exports = {
    /**
      * Create delete wf
      * @Input username
      * @Output send if user data deleted
      *
      */
    deleteWf: function (logger,wf, callback) {
        db.fbdi_data.remove({ 'Workflow': wf },
            function (err, doc, lastErrorObject) {
                logger.info('deleteWf -->fbdi_data.remove func()    ' + '   wf: ' + wf + JSON.stringify(doc) + ' ' + JSON.stringify(lastErrorObject) + ' ' + JSON.stringify(err));
                return callback(err, doc, lastErrorObject);
            }
        );
    },


    /**
      * get all workflow details
      * @Output complete wf details
      *
      */
    getAllWfDetails: function (logger,callback) {
        db.fbdi_data.find({}, { _id: 0 }, function (err, data) {
            logger.info('getAllWfDetails-->fbdi_data.find func(): '+ '  error: '+JSON.stringify(err)+'    data: '+JSON.stringify(data));
            if (err || !data || data.length == 0) {
                return callback('fail', err);
            } else {
                
                return callback('success', data)
            }
        }
        );
    },

    /**
      * Create wf
      * @Input jobname, package, num, wf
      * @Output new wf complete data
      *
      */
    createWf: function (logger,jobname, package, num, wf, callback) {
        db.fbdi_data.save({
            'JobName': jobname,
            'Package': package,
            'num': num,
            'Workflow': wf
        }, function (err, save) {
            logger.info('createWf--> fbdi_data.save func(): '+'  error:'+JSON.stringify(err)+'   data: '+JSON.stringify(save));
            if (err || !save) {
                return callback('fail', err);
            } else {
                return callback('success', save)
            }
        }
        );
    }

}
