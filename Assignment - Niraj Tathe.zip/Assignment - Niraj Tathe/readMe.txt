Following are the steps to execute the angular application.
1) First unzip the zip file.
2) Navigate inside Assignment folder
3) Open terminal/ cmd prompt inside same directory. 
(Make sure you node installed on your system. Otherwise you won't be able to install packages.)
4) Use command: npm install 
    This cmd will install all packages.
5) Use cmd: ng serve
    This will run the angular application. 
    Default port will be 4200. URL: http://localhost:4200

Check the app.

I spent my most of the time in Angular Material use.
CSS modal does not run on Angular 2+.
We have to use other package for this purpose. I have used Angular Material. It comes default with Angular 5.1.