import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Route } from '@angular/router';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import { DemoMaterialModule } from './material.module';

import { AppComponent } from './app.component';
import { CutsomerDataService } from './shared/cutsomer-data.service';
import { CustomerDetailsComponent } from './components/customer-details/customer-details.component';
import { DialogAddCustomer } from './app.component';
@NgModule({
  declarations: [
    AppComponent,
    CustomerDetailsComponent,
    DialogAddCustomer
  ],
  imports: [
    BrowserModule,
    RouterModule,
    FormsModule,
    HttpClientModule,
    DemoMaterialModule,
    BrowserAnimationsModule
  ],
  entryComponents: [AppComponent, DialogAddCustomer ],
  providers: [CutsomerDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
