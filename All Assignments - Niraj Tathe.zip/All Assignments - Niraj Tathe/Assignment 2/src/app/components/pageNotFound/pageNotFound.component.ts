import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-pageNotFound',
  templateUrl: './pageNotFound.component.html',
  styleUrls: ['./pageNotFound.component.css']
})

export class PageNotFoundComponent implements OnInit, OnDestroy { 
  constructor(){}
  
  ngOnInit(){ }

  ngOnDestroy(){}

}