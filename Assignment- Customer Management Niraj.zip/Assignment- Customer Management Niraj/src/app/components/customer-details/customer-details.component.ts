import { Component, OnInit,Input, ViewChild } from '@angular/core';
import { CutsomerDataService } from '../../shared/cutsomer-data.service';
@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {
  @Input() currentIndex: number;
  constructor(private custService: CutsomerDataService) { }

  ngOnInit() {
  }

  addTag(tagName){
    
    if(this.custService.customerData[this.currentIndex].tags === undefined && tagName.length>0){
      this.custService.customerData[this.currentIndex].tags = [];
      this.custService.customerData[this.currentIndex].tags.push(tagName);
      
    }else if(tagName.length >0){
      this.custService.customerData[this.currentIndex].tags.push(tagName);
      
    }
    
  }


}
