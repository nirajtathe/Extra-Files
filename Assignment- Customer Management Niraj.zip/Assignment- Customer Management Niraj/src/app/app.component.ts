import { Component, Inject } from '@angular/core';
import { CutsomerDataService } from './shared/cutsomer-data.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private custService: CutsomerDataService, public dialog: MatDialog){ }
  currentIndex=-1;
  
  ngOnInit() {
    this.custService.getAllDataFromFile()
      .subscribe(
        (res: any)=>{
          this.custService.customerData= res;
        }
      );
  }

  updateIndex(index){
    this.currentIndex = index;
  }

  addCustomer(){
    let dialogRef = this.dialog.open(DialogAddCustomer, {
      width: '500px',
      data: { name:null, email:null, location:null}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      
      if(result.name.length > 0 && this.emailValid(result.email) && result.location.length >0)
      { 
        this.custService.customerData.push(
          {
            name: result.name,
            email: result.email,
            location: result.location
          }
        );
      }
      else{
        console.log('Invalid Data');
      }
   });
  }

  emailValid(email:string){
    let EMAIL_REGEXP = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
    if(EMAIL_REGEXP.test(email)){
      return true;
    }
    return false;
  }

  deleteCustomer(){}
}

@Component({
  selector: 'dialog-add-customer',
  templateUrl: 'dialog-add-customer.html',
})
export class DialogAddCustomer {

  constructor(
    public dialogRef: MatDialogRef<DialogAddCustomer>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
