import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class CutsomerDataService {
  customerData: any[]= [];
  
  constructor(private http: HttpClient) { 
  }

  getAllDataFromFile(){
    return this.http.get('./customer.json');
  }


}
