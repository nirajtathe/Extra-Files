Part A) Angular Project :
Steps: 1) Unzipped the Angular Proj
	2) Go inside the project directory
	3) Run cmd: "npm install"
	4) Run App: "ng serve"
	5) Go to url : "http://localhost:4200"
	6) When we click on configure button response will be dispalyed on the console.

Part B) Node Js App (REST API):
Steps:	1) unzipped the node js project
	2) Go inside the project directory
	3) Run cmd: "npm install"
	4) Run App: "node app.js"
	5) The REST API's will be available at : 
		POST request: "http://localhost:4200/api" 