import { Injectable, OnInit } from '@angular/core';
import { Http,Response } from '@angular/http';
@Injectable()
export class DbConnectService implements OnInit{
  private device:{devicename: string, loopback:string,interfaces: { name:string, ipadd: string}[]}[]=[];
 
  constructor(private http:Http) { }
  
  ngOnInit(){
  }

  getData(){
    return this.device;
  }
  addData(device){
    this.device.push(device);
    console.log(this.device);
  }
  callPost(index){
    this.http.post('http://localhost:3000/api',this.device[index])
      .subscribe(
        (res:Response)=>{
          console.log(res);
        },
        (error)=>{
          console.log(error);
        }
      );

  }
}
