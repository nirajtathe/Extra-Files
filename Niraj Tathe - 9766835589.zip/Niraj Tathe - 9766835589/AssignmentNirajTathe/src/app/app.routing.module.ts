import {Route, RouterModule} from '@angular/router';
import {NgModule} from '@angular/core';

import { AppComponent } from './app.component';
import { AddDeviceComponent } from './components/add-device/add-device.component';
import { ConfigureDeviceComponent } from './components/configure-device/configure-device.component';
import { PagenotfoundComponent } from './components/pagenotfound/pagenotfound.component';
import { RootRenderer } from '@angular/core/src/render/api';
import { HomeComponent } from './components/home/home.component';
import { ViewInterfacesComponent } from './components/view-interfaces/view-interfaces.component';
import { DisplayInterfaceDataComponent } from './components/configure-device/display-interface-data/display-interface-data.component';

const routes:Route [] =[
    {path : '' , redirectTo: '/home', pathMatch: 'full'},
    {path: 'home', component: HomeComponent},
    {path: 'devices', component: AddDeviceComponent},
    {path: 'configure', component: ConfigureDeviceComponent,children :[
        {path:':id',component: DisplayInterfaceDataComponent}
    ]},
    {path: 'viewInterfaces', component: ViewInterfacesComponent},
    {path: '**', component : PagenotfoundComponent}
];
@NgModule({
    imports: [
        RouterModule.forRoot(routes)
    ],
    exports: [
        RouterModule
    ]
})

export class AppRoutingModule{}