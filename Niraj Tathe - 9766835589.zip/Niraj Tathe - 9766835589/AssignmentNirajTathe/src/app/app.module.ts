import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppRoutingModule } from './app.routing.module';
import { AppComponent } from './app.component';
import { AddDeviceComponent } from './components/add-device/add-device.component';
import { ConfigureDeviceComponent } from './components/configure-device/configure-device.component';
import { PagenotfoundComponent } from './components/pagenotfound/pagenotfound.component';
import { HomeComponent } from './components/home/home.component';
import { DbConnectService } from './shared/db-connect.service';
import { ViewInterfacesComponent } from './components/view-interfaces/view-interfaces.component';
import { DisplayInterfaceDataComponent } from './components/configure-device/display-interface-data/display-interface-data.component';

@NgModule({
  declarations: [
    AppComponent,
    AddDeviceComponent,
    ConfigureDeviceComponent,
    PagenotfoundComponent,
    HomeComponent,
    ViewInterfacesComponent,
    DisplayInterfaceDataComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule
  ],
  providers: [DbConnectService],
  bootstrap: [AppComponent]
})
export class AppModule { }
