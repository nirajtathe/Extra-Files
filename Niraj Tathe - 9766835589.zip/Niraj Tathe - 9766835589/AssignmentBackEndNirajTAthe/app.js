var express=require('express'),
node_ssh = require('node-ssh'),
fs = require('fs'),
path = require('path'),
bodyParser=require('body-parser');
ssh = new node_ssh();

var app=express();
var port=process.env.PORT || 3000;


app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

apiRouter=require('./routes.js')();
app.use("/api",apiRouter);

app.get("/",function(req,res){
    res.send("<h2>Hi,<br> Welcome to SSH /Telnet API</h2>");
});

app.listen(port, function(){
console.log("Server started on port : "+port);
});