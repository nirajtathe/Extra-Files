var express=require('express');

var routes= function(farmerInfo){

    apiRouter=express.Router();
    apiRouter.route("/")
        .post(function(req,res){
            var deviceData=req.body;
    		console.log(deviceData);
    		var loopback= deviceData.loopback;
    		ssh.connect({
			  host: loopback,
			  username: 'cisco',
			  password: 'cisco'
			})

			.then(function() {
				ssh.execCommand('sh run', {})//{cwd:'/home/Angular/', stream:'both'})
					.then(function(result) {
					    console.log('STDOUT: ' + result.stdout);
					    res.send(result.stdout);
					    console.log('STDERR: ' + result.stderr);
				})
			})

           	//res.status(201).send(deviceData.loopback);
        })
        .get(function(req,res){
            res.send('Get request received');
        });
       return apiRouter;
}

module.exports = routes;
