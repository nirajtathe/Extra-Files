import { Component, OnInit } from '@angular/core';
import { DbConnectService } from '../../shared/db-connect.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  interfaces: { name:string, ipadd: string}[]=[];
  constructor(private dbconnect: DbConnectService, private router:Router) { }
  
  devices=[];
  ngOnInit() {
    this.devices=this.dbconnect.getData();
  }

  onAdd(formData){
    this.devices.push({devicename:formData.form._value.hostname ,
          loopback: formData.form._value.loopback, interfaces:[]});
    // console.log(formData.form._value.hostname);
    // console.log(formData.form._value.loopback);
    formData.reset();
  }
  showDialog = false;
  
  onDelete(index: number){
    this.devices.splice(index,1);
  }

  checkUniqueHost(hostname: string){
    let result =false;
    if(this.devices.length == 0 || hostname== null || hostname.length == 0)
      return result;
    for(let device of this.devices){
      if(device.devicename === hostname){
        result=true;
        break;
      }
    }
    return result;
  }

  checkUniqueDeviceLoopback(loopback:string){
    let result =false;
    if(this.devices.length == 0 || loopback== null || loopback.length == 0)
      return result;
    for(let device of this.devices){
      if(device.loopback === loopback){
        result=true;
        break;
      }
      
      for(let dinterface of device.interfaces){
          if(dinterface.ipadd === loopback){
            result=true;
            break;
          }
        }
      
      if(result=== true){
        break;
      }
    }

    if(this.interfaces.length == 0)
      return result;

    for(let dinterface of this.interfaces){
        if(dinterface.ipadd === loopback){
          result=true;
          break;
        }
    }
    return result;
  }

  ipValidator(loopback){
    if(loopback==null)
      return false;
    var blocks = loopback.split(".");
    if(blocks.length === 4) {
      return blocks.every(function(block) {
        return !isNaN(block) && parseInt(block,10) >=0 && parseInt(block,10) <= 255;
      });
    }
    return false;
  }

}
