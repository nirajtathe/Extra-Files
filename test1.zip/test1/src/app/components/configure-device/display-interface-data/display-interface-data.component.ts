import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { DbConnectService } from '../../../shared/db-connect.service';
@Component({
  selector: 'app-display-interface-data',
  templateUrl: './display-interface-data.component.html',
  styleUrls: ['./display-interface-data.component.css']
})
export class DisplayInterfaceDataComponent implements OnInit {
  valid = false;
  hostname='';
  id: number= null;
  devices=[];
  interfaces=[];
  constructor(private dbConnect:DbConnectService,private router: Router,
              private route:ActivatedRoute) { }

  ngOnInit() {
    this.devices= this.dbConnect.getData();
    this.route.params
      .subscribe(
        (params: Params)=>{
          this.id= params['id'];
          this.interfaces = this.devices[this.id].interfaces;
          this.hostname = this.devices[this.id].devicename;
        }
      );
    
    
  }

  

}
