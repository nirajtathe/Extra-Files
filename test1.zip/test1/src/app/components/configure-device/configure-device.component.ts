import { Component, OnInit } from '@angular/core';
import { DbConnectService } from '../../shared/db-connect.service';
//import { Router } from '@angular/router';

@Component({
  selector: 'app-configure-device',
  templateUrl: './configure-device.component.html',
  styleUrls: ['./configure-device.component.css']
})
export class ConfigureDeviceComponent implements OnInit {
  devices=[];
  constructor(private dbConnect: DbConnectService) { }

  ngOnInit() {
    this.devices = this.dbConnect.getData();
  }
  
  configure(index){
    this.dbConnect.callPost(index);
  }
}
