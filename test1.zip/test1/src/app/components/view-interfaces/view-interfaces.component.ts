import { Component, OnInit } from '@angular/core';
import { DbConnectService } from '../../shared/db-connect.service';

@Component({
  selector: 'app-view-interfaces',
  templateUrl: './view-interfaces.component.html',
  styleUrls: ['./view-interfaces.component.css']
})
export class ViewInterfacesComponent implements OnInit {
  valid = false;
  tried= false;
  interfaces=[];
  devices=[];
  constructor(private dbconnect: DbConnectService) { }

  ngOnInit() {
    this.devices = this.dbconnect.getData();
  }

  getInterfaces(hostname){
    this.tried=true;
    if(this.devices.length == 0 || hostname== null || hostname.length == 0)
      return this.valid;

    for(let device of this.devices){
      if(device.devicename === hostname)
      {
        this.interfaces=device.interfaces;
        this.valid=true;
      }
    }
  }

}
