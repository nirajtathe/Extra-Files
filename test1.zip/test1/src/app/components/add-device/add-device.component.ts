import { Component, OnInit,ViewChild } from '@angular/core';
import { DbConnectService } from '../../shared/db-connect.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-device',
  templateUrl: './add-device.component.html',
  styleUrls: ['./add-device.component.css']
})
export class AddDeviceComponent implements OnInit {
  interfaces: { name:string, ipadd: string}[]=[];
  constructor(private dbconnect: DbConnectService, private router:Router) { }
  @ViewChild('loopback') devLoop;
  devices=[];
  ngOnInit() {
    this.devices=this.dbconnect.getData();
  }

  onAdd(){
    this.interfaces.push({name:'' ,ipadd:''});
  }

  onDelete(index){
    this.interfaces.splice(index,1);
  }

  checkUniqueHost(hostname: string){
    let result =false;
    if(this.devices.length == 0 || hostname== null || hostname.length == 0)
      return result;
    for(let device of this.devices){
      if(device.devicename === hostname){
        result=true;
        break;
      }
    }
    return result;
  }

  checkUniqueDeviceLoopback(loopback:string){
    let result =false;
    if(this.devices.length == 0 || loopback== null || loopback.length == 0)
      return result;
    for(let device of this.devices){
      if(device.loopback === loopback){
        result=true;
        break;
      }
      
      for(let dinterface of device.interfaces){
          if(dinterface.ipadd === loopback){
            result=true;
            break;
          }
        }
      
      if(result=== true){
        break;
      }
    }

    if(this.interfaces.length == 0)
      return result;

    for(let dinterface of this.interfaces){
        if(dinterface.ipadd === loopback){
          result=true;
          break;
        }
    }
    return result;
  }

  checkUniqueInterfaceName(interfaceName: string,index){
    let result =false;
    if(this.interfaces.length == 0 || interfaceName== null || interfaceName.length == 0)
      return result;
    let i=0;
    for(let dinterface of this.interfaces){
      if(i!=index)
        if(dinterface.name === interfaceName){
          result=true;
          break;
        }
      
      i++;
    }
    return result;
  }

  checkUniqueInterfaceLoopback(interfaceIpadd: string,index,deviceLoop){
    let result =false;

    if(this.interfaces.length == 0 || interfaceIpadd== null || interfaceIpadd.length == 0)
      return result;

    //inner interfac check
    let i=0;
    for(let dinterface of this.interfaces){
      if(i!=index)
        if(dinterface.ipadd === interfaceIpadd){
          result=true;
          break;
        }

      i++;
    }
  
    if(deviceLoop === interfaceIpadd){
      return true;
    }
    if(this.devices.length == 0)
      return result;
    
    for(let device of this.devices){
      if(device.loopback === interfaceIpadd)
      {
        result=true;
        break;
      }
      for(let dinterface of device.interfaces){
        if(dinterface.ipadd === interfaceIpadd){
          result=true;
          break;
        }
      }
      if(result=== true){
        break;
      }
    }
    
    return result;
  }

  checkInterfaceName(data:string){
    let result=false;
    if(data== null)
      return false;
    if(data.startsWith('Loopback'))
      result= true;
    
    return result;
  }

  checkInterfaces(){
    let result = true;
    for(let data of this.interfaces){
      if(data.name === '' || data.ipadd===''){
        result= false;
        break;
      }
      else{
        if(data.name.startsWith('Loopback') && data.ipadd.length <= 15)
          result= true;
        else{
          result =false;
          break;
        }
      }
    }
    return result;
  }

  onSave(name,dloopback){
    let client={
      devicename:name,
      loopback: dloopback,
      interfaces: this.interfaces
    }
    this.dbconnect.addData(client);
    this.router.navigate(['/home']);
  }

  ipValidator(loopback){
    if(loopback==null)
      return false;
    var blocks = loopback.split(".");
    if(blocks.length === 4) {
      return blocks.every(function(block) {
        return !isNaN(block) && parseInt(block,10) >=0 && parseInt(block,10) <= 255;
      });
    }
    return false;
  }

}
