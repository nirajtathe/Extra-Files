import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { trigger, state, style, animate, transition } from '@angular/animations';


import { DbConnectService } from '../../shared/db-connect.service';

@Component({
  selector: 'app-popup',
  templateUrl: './popup.component.html',
  styleUrls: ['./popup.component.css'],
  animations: [
    trigger('dialog', [
      transition('void => *', [
        style({ transform: 'scale3d(.3, .3, .3)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
      ])
    ])
  ]
})
export class PopupComponent implements OnInit {

  @Input() closable = true;
  @Input() visible: boolean;
  @Output() visibleChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  interfaces: { name:string, ipadd: string}[]=[];
  constructor(private dbconnect: DbConnectService) { }
  
  devices=[];
  ngOnInit() {
    this.devices=this.dbconnect.getData();
  }

  close() {
    this.visible = false;
    this.visibleChange.emit(this.visible);
  }


  checkUniqueHost(hostname: string){
    let result =false;
    if(this.devices.length == 0 || hostname== null || hostname.length == 0)
      return result;
    for(let device of this.devices){
      if(device.devicename === hostname){
        result=true;
        break;
      }
    }
    return result;
  }

  checkUniqueDeviceLoopback(loopback:string){
    let result =false;
    if(this.devices.length == 0 || loopback== null || loopback.length == 0)
      return result;
    for(let device of this.devices){
      if(device.loopback === loopback){
        result=true;
        break;
      }
      
      for(let dinterface of device.interfaces){
          if(dinterface.ipadd === loopback){
            result=true;
            break;
          }
        }
      
      if(result=== true){
        break;
      }
    }

    if(this.interfaces.length == 0)
      return result;

    for(let dinterface of this.interfaces){
        if(dinterface.ipadd === loopback){
          result=true;
          break;
        }
    }
    return result;
  }

  ipValidator(loopback){
    if(loopback==null)
      return false;
    var blocks = loopback.split(".");
    if(blocks.length === 4) {
      return blocks.every(function(block) {
        return !isNaN(block) && parseInt(block,10) >=0 && parseInt(block,10) <= 255;
      });
    }
    return false;
  }


}
