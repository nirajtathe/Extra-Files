import { AssignmentNirajTathePage } from './app.po';

describe('assignment-niraj-tathe App', () => {
  let page: AssignmentNirajTathePage;

  beforeEach(() => {
    page = new AssignmentNirajTathePage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
