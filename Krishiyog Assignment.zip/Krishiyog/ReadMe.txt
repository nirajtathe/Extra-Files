The frontend is developed with Angular 4. REST API's are created using Expressjs and MongoDB.

Pre-requisite: 
	-System should have NodeJs and Angular cli installed.

MongoDB setup:
1) First create a collection (Collection name inside db script "FarmerInfoCollection") in your MongoDB database (db name provided inside the app.js "farmerInfoAPI". Created this database on my system.). 
2) Load the script provided inside MongoDB folder.

ExpressJs:
1) Unzipped the zip provided inside ExpressAPI folder.
2) Navigate inside the unzipped folder using cmd/terminal. Use cmd: "npm install" . This will install all the dependecies.
3) Start the server. Use cmd: "nodemon app.js" OR "node app.js" 

Angular4:
1) Uzipped the zip provided inside Angular App Folder.
2) Navigate inside unzipped folder using cmd/terminal. Use cmd: "npm install". 
3) If Angular cli not installed already. Use cmd: "npm install -g @angular/cli" 
4) Start the application. Use cmd: "ng serve"

Navigate to ViewData tab section to view the data fetched from Rest API.